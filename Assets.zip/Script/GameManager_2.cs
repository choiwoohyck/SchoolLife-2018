﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager_2 : MonoBehaviour {

    UIController uCon;
    PlayerController pCon;
    int cnt = 0;

    int dialog = 0;
    bool runOneTime = true;

    // Use this for initialization
    void Start()
    {
        uCon = GameObject.Find("UIController").GetComponent<UIController>();
        pCon = GameObject.Find("Player").GetComponent<PlayerController>();
        pCon.Load();
    }

    // Update is called once per frame
    void Update () {
		
	}
}
