﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour {

    UIController uCon;
    PlayerController pCon;
    public GameObject wall;
    int cnt = 0;

    int dialog = 0;
    bool runOneTime = true;

    public bool isSecond = false;

    void Start() {
        uCon = GameObject.Find("UIController").GetComponent<UIController>();
        pCon = GameObject.Find("Player").GetComponent<PlayerController>();

        if(!isSecond)
            dialog = 1;
        if (isSecond)
        {
            GameObject.Find("Main Camera").GetComponent<CameraController>().Reset();
        }
    }

    void Update() {
        if (dialog == 1)
        {
            if (runOneTime)
            {
                runOneTime = false;
                uCon.StartCoroutine(uCon.Dialog("주인공", "자, 그럼 '공부'를 시작해볼까?", false));
            }
            if (Input.GetMouseButtonDown(0) && !uCon.isDialogStart)
            {

                uCon.StartCoroutine(uCon.Dialog("주인공", "일단 바로 옆반부터 가봐야겠어", true));
                runOneTime = false;
                dialog = 0;
            }
        }
    }

    public void NextScene(int scene)
    {
        DataManager.Instance.moveSpeed = pCon.moveSpeed;
        DataManager.Instance.dashLength = pCon.dashLength;
        DataManager.Instance.hp = pCon.hp;
        DataManager.Instance.maxHp = pCon.maxHp;
        DataManager.Instance.damage = pCon.damage;

        DataManager.Instance.weaponID = pCon.weaponID;
        DataManager.Instance.weaponID_1 = pCon.weaponID_1;
        DataManager.Instance.weaponID_2 = pCon.weaponID_2;

        DataManager.Instance.items = pCon.items;

        DataManager.Instance.weapon = pCon.weapon;
        DataManager.Instance.weapon_1 = pCon.weapon_1;
        DataManager.Instance.weapon_2 = pCon.weapon_2;

        for(int i = 0; i<pCon.items; i++)
        {
            DataManager.Instance.pickedItems[i] = pCon.pickedItems[i];
        }

        SceneManager.LoadScene(scene);
    }

    public void End()
    {
        SceneManager.LoadScene(0);
    }

    public void GameStart()
    {
        wall.gameObject.SetActive(false);
    }

    public IEnumerator Next(int scene)
    {
        DataManager.Instance.moveSpeed = pCon.moveSpeed;
        DataManager.Instance.dashLength = pCon.dashLength;
        DataManager.Instance.hp = pCon.hp;
        DataManager.Instance.maxHp = pCon.maxHp;
        DataManager.Instance.damage = pCon.damage;

        DataManager.Instance.weaponID = pCon.weaponID;
        DataManager.Instance.weaponID_1 = pCon.weaponID_1;
        DataManager.Instance.weaponID_2 = pCon.weaponID_2;

        DataManager.Instance.items = pCon.items;

        DataManager.Instance.weapon = pCon.weapon;
        DataManager.Instance.weapon_1 = pCon.weapon_1;
        DataManager.Instance.weapon_2 = pCon.weapon_2;

        for (int i = 0; i < pCon.items; i++)
        {
            DataManager.Instance.pickedItems[i] = pCon.pickedItems[i];
        }
        yield return new WaitForSeconds(5.0f);

        SceneManager.LoadScene(scene);
    }

        
}
