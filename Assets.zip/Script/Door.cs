﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Door : MonoBehaviour {

    public GameObject room;
    UIController uCon;
    CameraController cCon;
    SpriteRenderer sr;
    Room roomInfo;
    EnemySpawner spawner;
    public int doorType;    //0 = 왼쪽.   1 = 오른쪽,    2 = 위,      3 = 아래
    public bool isMoved = false;

    public Sprite openDoor;

	void Start () {
        roomInfo = room.GetComponent<Room>();
        uCon = GameObject.Find("UIController").GetComponent<UIController>();
        cCon = GameObject.Find("Main Camera").GetComponent<CameraController>();
        sr = GetComponent<SpriteRenderer>();
        spawner = GameObject.Find("EnemySpawner").GetComponent<EnemySpawner>();
	}
	
	void Update () {
        if (roomInfo.isCleared)
        {
            sr.sprite = openDoor;
        }

    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player") && !isMoved && roomInfo.isCleared)
        {
            if(doorType == 0)
            {
                other.gameObject.transform.position = roomInfo.leftRoom.GetComponent<Room>().rightDoor.transform.position;
                other.GetComponent<PlayerController>().mapPosX -= 1;
                roomInfo.leftRoom.GetComponent<Room>().rightDoor.GetComponent<Door>().isMoved = true;
            }
            if (doorType == 1)
            {
                other.gameObject.transform.position = roomInfo.rightRoom.GetComponent<Room>().leftDoor.transform.position;
                other.GetComponent<PlayerController>().mapPosX += 1;
                roomInfo.rightRoom.GetComponent<Room>().leftDoor.GetComponent<Door>().isMoved = true;
            }
            if (doorType == 2)
            {
                other.gameObject.transform.position = roomInfo.upRoom.GetComponent<Room>().botDoor.transform.position;
                other.GetComponent<PlayerController>().mapPosY += 1;
                roomInfo.upRoom.GetComponent<Room>().botDoor.GetComponent<Door>().isMoved = true;
            }
            if (doorType == 3)
            {
                other.gameObject.transform.position = roomInfo.botRoom.GetComponent<Room>().upDoor.transform.position;
                other.GetComponent<PlayerController>().mapPosY -= 1;
                roomInfo.botRoom.GetComponent<Room>().upDoor.GetComponent<Door>().isMoved = true;
            }
            spawner.Spawn();
            isMoved = true;
            uCon.Fade();
            cCon.Reset();
        }
    }

    void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            isMoved = false;
        }
    }
}
