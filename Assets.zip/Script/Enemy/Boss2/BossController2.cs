﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;

public class BossController2 : MonoBehaviour {

    public GameObject gravity_bullet;
    public GameObject slash;
    public GameObject bigslashModel;
    public GameObject egoModel;
    public GameObject swordRainModel;
    public GameObject bulletModel;


    GameObject player;
    PlayerController pCon;

    EnemyBase eb;

    UIController uCon;
    CameraController cCon;

    float attackDelay = 0.0f;


    public int pattern2Count = 0;
    int pattern = 6;
    int pattern5Count = 0;
    int pattern6Count = 0;
    int pattern6Case = 0;
    int pattern6totalCount = 0;
    int attackCount = 1;
    int pattern5Case = 0;

    bool pattern2Start = true;
    bool pattern4Start = true;

    float pattern4Timer = 0;
    float pattern6Delay = 0;
    float attackTimer = 0;

	// Use this for initialization
	void Start () {
        player = GameObject.Find("Player");
        pCon = player.GetComponent<PlayerController>();
        pattern6Case = Random.Range(1, 4);
        uCon = GameObject.Find("UIController").GetComponent<UIController>();
        cCon = GameObject.Find("Main Camera").GetComponent<CameraController>();
        eb = GetComponent<EnemyBase>();

        uCon.bossEmpty.gameObject.SetActive(true);
        uCon.bossFull.gameObject.SetActive(true);
    }
	
	// Update is called once per frame
	void Update () {

        uCon.bossFull.fillAmount = eb.hp / eb.startHp;

        attackDelay += Time.deltaTime;
        pattern6Delay += Time.deltaTime;

        attackTimer += Time.deltaTime;

        if(eb.hp <= 0)
        {
            StartCoroutine(Dead());
        }

        if (attackCount != 0)
        {

        }
        else
        {
            pattern = 1;
        }

        if (pattern == 2 && attackDelay >= Random.Range(2,5))
        {

            if (pattern2Count == 5)
                pattern = 3;

            if (pattern2Count == 0)
            {
                transform.position = new Vector2(pCon.mapPosX*60+22, transform.position.y);

                GameObject ego = Instantiate(egoModel, new Vector2(pCon.mapPosX*60-15, transform.position.y), Quaternion.identity);            

                pattern2Start = false;
            }

           

            GameObject s = Instantiate(slash, transform.position, Quaternion.identity);
            GameObject s2 = Instantiate(slash, new Vector2(pCon.mapPosX*60-13, pCon.mapPosY*60-2.5f), Quaternion.identity);
            pattern2Count++;

            
            attackDelay = 0;
        }

        if (pattern == 3 && attackDelay >= 3)
        {
            float gPos = transform.position.x;

            if (transform.position.x >= player.transform.position.x)
            {
                gPos -= 4.5f;
            }
            else
                gPos += 4.5f;

            GameObject g = Instantiate(gravity_bullet, new Vector2(transform.position.x + gPos , transform.position.y), Quaternion.identity);

            attackDelay = 0;
            attackCount++;
            pattern = 4;
        }

        if (pattern == 4  && attackDelay >= 4)
        {
            if (pattern4Start)
            {
                GameObject bigSlash = Instantiate(bigslashModel, transform.position, Quaternion.identity);
                pattern4Start = false;
            }

            pattern4Timer += Time.deltaTime;
            if (pattern4Timer >= 5)
            {
                pattern2Count = 0;
                pattern4Start = true;
                pattern = 5;
                pattern5Case = Random.Range(0, 2);
                pattern4Timer = 0;
                
            }
        } 

        if (pattern == 5 && attackDelay >= 2)
        {
           
            GameObject[] bullet = new GameObject[10];

            for (int i = 0; i < 10; i++)
            {
                Vector2 spawnPos;

                if (pattern5Case == 0) {
                    spawnPos = new Vector2(i * 5 + pCon.mapPosX * 60 - 15, pCon.mapPosY * 60 + 30);
                    bullet[i] = Instantiate(swordRainModel, spawnPos, Quaternion.identity);
                }
                else
                {
                    spawnPos = new Vector2(i * 5 + pCon.mapPosX * 60 - 13, pCon.mapPosY * 60 + 30);
                    bullet[i] = Instantiate(swordRainModel, spawnPos, Quaternion.identity);
                }

              
            }


            if (pattern5Case == 0)
                pattern5Case = 1;
            else
                pattern5Case = 0;

            pattern5Count++;

            if (pattern5Count >= 2)
            {
                pattern = 2;
                pattern2Count = 0;

                pattern5Count = 0;
            }

            attackDelay = 0;

        }

        if (pattern == 6 && attackDelay >= 2)
        {

            if (pattern6Delay >= 0.05f)
            {
                GameObject b = Instantiate(bulletModel, transform.position, Quaternion.identity);
                b.GetComponent<BulletController2>().moveWidth = pattern6Case * 10;
                pattern6Count++;
                pattern6Delay = 0;

            }

            if (pattern6totalCount >= 3) {
                pattern = 2;
            }

            if (pattern6Count >= 10)
            {
                attackDelay = 0;
                pattern6Count = 0;
                pattern6totalCount++;
                pattern6Case = Random.Range(1, 4);
            }

        }
    }

    void OnTriggerEnter2D(Collider2D coll)
    {
        
        if (coll.CompareTag("PlayerAttack"))
        {
            Attack at;
            at = coll.GetComponent<Attack>();
            eb.isDamaged = true;
            eb.hp -= at.damage - eb.DEF;
            eb.StartCoroutine(eb.Damaged(at.isLeft, at.ccType, at.power));
            if (at.isRangedAttack)
                Destroy(coll.gameObject);
        }
    }

    IEnumerator Dead()
    {
        Transform original = cCon.targetTrans;
        cCon.targetTrans = gameObject.transform;
        yield return new WaitForSeconds(2.0f);
        cCon.targetTrans = original;
        uCon.bossEmpty.gameObject.SetActive(false);
        uCon.bossFull.gameObject.SetActive(false);
        if (eb.haveItem)
        {
            Instantiate(eb.dropItems[UnityEngine.Random.Range(0, eb.dropItems.Length)], transform.position, Quaternion.identity);
        }

        GameObject.Find("GameManager").GetComponent<GameManager>().StartCoroutine(GameObject.Find("GameManager").GetComponent<GameManager>().Next(4));

        Destroy(gameObject);
    }

}
