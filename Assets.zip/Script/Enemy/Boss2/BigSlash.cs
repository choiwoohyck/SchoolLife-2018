﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BigSlash : MonoBehaviour {

    public Sprite shadow;
    public Sprite real ;

    SpriteRenderer spr;

    GameObject player;

    bool isLeft = false;

    float lifeTime;
    float moveSpeed = 15.0f;

	// Use this for initialization
	void Start () {
        player = GameObject.Find("Player");
        spr = GetComponent<SpriteRenderer>();
        
        Vector2 playerPos = player.transform.position;

        if (playerPos.x <= transform.position.x)
        {
            spr.flipX = true;
            isLeft = false;
        }

	}
	
	// Update is called once per frame
	void Update () {
        lifeTime += Time.deltaTime;


        if (lifeTime <= 2)
        {
            spr.sprite = shadow;
        }

        else
        {
            spr.sprite = real;

            if (isLeft)
                transform.Translate(Vector3.right * moveSpeed * Time.deltaTime);
            else
                transform.Translate(Vector3.left * moveSpeed * Time.deltaTime);
        }

        if (transform.position.x <= player.GetComponent<PlayerController>().mapPosX * 60 - 40 || transform.position.x >= player.GetComponent<PlayerController>().mapPosX * 60 + 40)
            Destroy(gameObject);
    }

    void OnTriggerEnter2D(Collider2D coll)
    {
        if (coll.gameObject.CompareTag("Player"))
            coll.GetComponent<PlayerController>().Attacked(10);
    }
}
