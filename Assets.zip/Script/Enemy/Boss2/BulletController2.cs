﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletController2 : MonoBehaviour {

    float moveAngle;
    float x = 0;
    float y = 0;
    float moveSpeed = 50.0f;
    public float moveWidth = 30.0f;

    GameObject player;
    GameObject owner;

    EnemyBase eb;


    // Use this for initialization
    void Start () {

        x = transform.position.x;
        y = transform.position.y;

        player = GameObject.Find("Player");
        owner = GameObject.Find("Boss2(Clone)");
	}
	
	// Update is called once per frame
	void Update () {
        moveAngle += Time.deltaTime * moveWidth;

        if (owner == null)
            Destroy(gameObject);

        if (player.transform.position.x <= owner.transform.position.x)
            x -= 30.0f * Time.deltaTime;
        else
            x += 30.0f * Time.deltaTime;
        y += Mathf.Sin(moveAngle) * Time.deltaTime * 60.0f;
        Vector3 movement = new Vector3(x , y );
        transform.position = movement;

        if (transform.position.x <= -30.0f)
            Destroy(gameObject);
	}

    void OnTriggerEnter2D(Collider2D coll)
    {
        if (coll.gameObject.CompareTag("Player"))
        {
            coll.GetComponent<PlayerController>().Attacked(2);
            Destroy(gameObject);
        }
        if(coll.CompareTag("ground") || coll.CompareTag("wall")){
            Destroy(gameObject);
        }
    }
}
