﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Boss2Ego : MonoBehaviour {


    GameObject owner;
    float moveSpeed = 5.0f;
    Rigidbody2D rid;

	// Use this for initialization
	void Start () {
        owner = GameObject.Find("Boss2(Clone)");
        
	}
	
	// Update is called once per frame
	void Update () {

        if (owner.GetComponent<BossController2>().pattern2Count == 10)
            Destroy(gameObject);

    }

  


}
