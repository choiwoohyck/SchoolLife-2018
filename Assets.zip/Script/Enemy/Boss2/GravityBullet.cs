﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GravityBullet : MonoBehaviour {

    // Use this for initialization

    GameObject player;
    
    float pullPower = 9.0f;
    float moveAngle;
    float x = 0.0f;
    float y = 0.0f;

    float lifeTime = 0.0f;

    void Start () {
        player = GameObject.Find("Player");
	}
	
	// Update is called once per frame
	void Update () {

        lifeTime += Time.deltaTime;

        if (lifeTime >= 2.0f)
            Destroy(gameObject);

        Vector2 p = transform.position - player.transform.position;
        moveAngle = Mathf.Atan2(p.y,p.x);

        if (Mathf.Abs(player.transform.position.x - transform.position.x) >= 1.0f)
        {
            x = Mathf.Cos(moveAngle) * pullPower * Time.deltaTime;
            y = Mathf.Sin(moveAngle) * pullPower * Time.deltaTime;

            Vector3 movement = new Vector2(x, y);
            player.transform.position += movement;

            Debug.Log(movement);
        }
	}

    void OnTriggerEnter2D(Collider2D coll)
    {
        if (coll.gameObject.CompareTag("Player"))
            coll.GetComponent<PlayerController>().Attacked(3);
    }
}
