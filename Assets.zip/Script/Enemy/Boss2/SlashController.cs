﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SlashController : MonoBehaviour {

    // Use this for initialization
    bool isLeft;
    
   
    float moveSpeed = 8.0f;
	void Start () {

        if (transform.position.x >= GameObject.Find("Player").GetComponent<PlayerController>().mapPosX*60 + 5)
        {
            GetComponent<SpriteRenderer>().flipX = true;
            isLeft = false;
        }      
        else
        {
            isLeft = true;
        }
    }
	
	// Update is called once per frame
	void Update () {

        if (isLeft)
        {
            transform.Translate(Vector3.right * moveSpeed * Time.deltaTime);
        }

        else
        {
            transform.Translate(Vector3.left * moveSpeed * Time.deltaTime);

        }




    }

    void OnTriggerEnter2D(Collider2D coll)
    {
        if (coll.gameObject.CompareTag("Player"))
            coll.GetComponent<PlayerController>().Attacked(4);
        if (coll.gameObject.CompareTag("wall") || coll.gameObject.CompareTag("ground"))
            Destroy(gameObject);
    }
}
