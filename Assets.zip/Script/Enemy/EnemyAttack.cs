﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyAttack : MonoBehaviour {

	public float damage = 1.0f;
    public bool isRange= false;
    public bool isCharge = false;


    EnemyBase eb;
    SpriteRenderer sr;

    void Start()
    {   
        eb = GetComponentInParent<EnemyBase>();
        sr = GetComponent<SpriteRenderer>();
        damage = eb.damage + damage;
    }

    void Update()
    {
        if (!isRange && !isCharge)
        {
            if (eb.isLeft)
            {
                sr.flipX = true;
            }
            else
                sr.flipX = false;
        }
    }

	public IEnumerator DesTimer(bool left, float attackSpeed, float dummyRemoveTime){
		yield return new WaitForSeconds (attackSpeed);
		GetComponent<SpriteRenderer> ().color = new Color32 (255, 255, 255, 255);
		GetComponent<BoxCollider2D> ().enabled = true;
		if (left) {
			transform.Translate (Vector3.left * 0.01f);
		} else {
			transform.Translate (Vector3.right * 0.01f);
		}
		yield return new WaitForSeconds (dummyRemoveTime);
		GetComponent<SpriteRenderer> ().color = new Color32 (255, 0, 0, 150);
		GetComponent<BoxCollider2D> ().enabled = false;
		gameObject.SetActive (false);
	}

}
