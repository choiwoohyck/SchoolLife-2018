﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Biter : MonoBehaviour {

	EnemyBase eb; //Entity Base (EnemyBase스크립트)
	float attackTime = 2.0f;
	float attackDelay = 3.0f;	//공격간 딜레이 (공격 속도)
	float attackSpeed = 0.7f;   //공격 범위 표시 후 실제공격 전 까지의 시간
	float dummyRemoveTime = 0.3f; //공격 더미의 파괴 시간
	bool attackStart = false;

	public GameObject attackDummy;
	void Start () {
		eb = GetComponentInParent<EnemyBase> ();
	}

	void Update () {

		//if (eb.isLeft) {
		//	bc.offset = new Vector2 (-0.1f, -0.03f);
		//	bc.size = new Vector2 (0.5f, 0.2f);
		//} else {
		//	bc.offset = new Vector2 (0.1f, -0.03f);
		//	bc.size = new Vector2 (0.5f, 0.2f);
		//}
		if (attackStart == true) {
			if (attackTime <= attackDelay) {	  //attackSpeed초 마다 공격
				attackTime += Time.deltaTime;
			} else {
				attackTime = 0.0f;
				//공격(
				if (eb.isLeft) {
					attackDummy.transform.position = new Vector2 (transform.position.x - 1.6f, transform.position.y + 0.3f);
					attackDummy.SetActive (true);
				} else {
					attackDummy.transform.position = new Vector2 (transform.position.x + 1.6f, transform.position.y + 0.3f);
					attackDummy.SetActive (true);
				}
				eb.isAttacking = true;
				attackDummy.GetComponent<EnemyAttack> ().StartCoroutine (attackDummy.GetComponent<EnemyAttack> ().DesTimer (eb.isLeft, attackSpeed, dummyRemoveTime));
				StartCoroutine (StopToAttack ());	//공격이 끝날 때 까지 정지
				//)

			}
		}
	}

	void OnTriggerEnter2D(Collider2D other){
		
		if (other.CompareTag ("Player")) {
			eb.isStop = true;
		}
	}

	void OnTriggerStay2D(Collider2D other){
		if (other.CompareTag ("Player") && !eb.isDamaged) {
			attackStart = true;
		}
	}

	void OnTriggerExit2D(Collider2D other){
		if(other.CompareTag("Player")){
			eb.isStop = false;
			attackStart = false;
		}
	}

	IEnumerator StopToAttack(){	//공격이 끝날 때 까지 정지하기 위한 코루틴
		yield return new WaitForSeconds (attackSpeed + dummyRemoveTime);
		eb.isStop = false;
		eb.isAttacking = false;
	}



}	
