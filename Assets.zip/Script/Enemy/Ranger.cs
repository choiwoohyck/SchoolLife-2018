﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ranger : MonoBehaviour
{

    EnemyBase eb; //Entity Base (EnemyBase스크립트)
    float attackTime = 3.0f;
    float attackDelay = 2.0f;   //공격간 딜레이 (공격 속도)

    bool attackStart = false;

    Vector2 target;

    GameObject player;
    PlayerController pCon;
    public GameObject projectile;

    void Start()
    {
        player = GameObject.Find("Player");
        pCon = player.GetComponent<PlayerController>();
        eb = GetComponentInParent<EnemyBase>();
    }

    void Update()
    {
        if (attackStart == true)
        {
            if (attackTime <= attackDelay)
            {     //attackSpeed초 마다 공격
                attackTime += Time.deltaTime;
            }
            else
            {
                attackTime = 0.0f;
                //공격(;
                StartCoroutine(Targeting());
                //)
            }
        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {

        if (other.CompareTag("Player"))
        {
            Debug.Log("a");
            eb.isStop = true;
        }
    }

    void OnTriggerStay2D(Collider2D other)
    {
        if (other.CompareTag("Player") && !eb.isDamaged)
        {
            attackStart = true;
        }
    }

    void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            eb.isStop = false;
            attackStart = false;
        }
    }

    IEnumerator StopToAttack()
    {   //공격이 끝날 때 까지 정지하기 위한 코루틴
        yield return new WaitForSeconds(0.2f);
        eb.isStop = false;
        eb.isAttacking = false;
    }

    IEnumerator Targeting()
    {
        target = player.transform.position;

        yield return new WaitForSeconds(1.5f);

        GameObject bolt = Instantiate(projectile, transform.position, Quaternion.identity);
        bolt.transform.parent = transform.parent;
        bolt.GetComponent<Projectile>().targetPos = player.transform.position;
        eb.isAttacking = true;

        StartCoroutine(StopToAttack()); //공격이 끝날 때 까지 정지
        
    }

}
