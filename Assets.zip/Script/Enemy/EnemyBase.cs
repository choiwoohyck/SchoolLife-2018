﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBase : MonoBehaviour {

	//스탯
	public float hp = 10;
	public float startHp = 0;
	public float DEF = 0.0f; //방어력 (Defensive power)
	public float damage = 1.0f;
    public float strength = 0;  //강인함, cc면역률
    public bool isRange = false;   //원거리 공격을 하는가


	int moveFlag = 0; //0 = 정지 ,  1 = 왼쪽,  2 = 오른쪽
	public float moveSpeed = 2.0f;
	public bool isChasing = false;
    public bool isAvoid = false;
	public bool isStop = false;	//다른 스크립트에서 이 오브젝트의 이동을 멈추게 하기 위함
	public bool isDamaged = false; //공격받음
	public bool isLeft = true; //왼쪽을보고있음
	public bool isAttacking = false;
    public bool isCharging = false;
    bool chargeLeft = false;

    public bool isBoss = false;
    public bool isTutorial = false;

    float time = 0;
    float avoidTime = 2.0f;

    public GameObject[] dropItems = new GameObject[3];
    public bool haveItem = false;

    Vector2 target;

    SpriteRenderer sr;
	Rigidbody2D rid;
	public GameObject traceTarget;
    Animator anim;

	void Awake(){
		startHp = hp;
	}

	void Start () {
		StartCoroutine (ChangeMovement ());
		sr = GetComponent<SpriteRenderer> ();
		rid = GetComponent<Rigidbody2D> ();
        anim = GetComponent<Animator>();
    }
		

	void FixedUpdate () {
        if (!isBoss)
        {
            Move();
            if (hp <= 0)
            {
                if (haveItem)
                    Instantiate(dropItems[Random.Range(0, dropItems.Length)], transform.position, Quaternion.identity);
                if (isTutorial)
                {
                    GameObject.Find("GameManager").GetComponent<TutorialManager>().isMonsterDead = true;
                }
                Destroy(gameObject);
            }
        }
        if (isCharging)
        {
            if (chargeLeft)
            {
                if (target.x < transform.position.x)
                    transform.Translate(Vector2.left * moveSpeed * 3 * Time.deltaTime);
                else
                {
                    isCharging = false;
                    isStop = false;
                    GetComponentInChildren<Giant>().StartCoroutine(GetComponentInChildren<Giant>().StopToAttack());
                }
            }
            else
            {
                if (target.x > transform.position.x)
                    transform.Translate(Vector2.right * moveSpeed * 3 * Time.deltaTime);
                else
                {
                    isCharging = false;
                    isStop = false;
                    GetComponentInChildren<Giant>().StartCoroutine(GetComponentInChildren<Giant>().StopToAttack());
                }
            }

        }
	}

	void Move(){

		Vector3 moveVelocity = Vector3.zero;

		//플레이어 추적중
		if (isChasing && !isRange) {
			Vector3 playerPos = traceTarget.transform.position;

			if (Mathf.Abs (playerPos.x - transform.position.x) < 0.4f) {
				moveFlag = 0;
			} else if (playerPos.x < transform.position.x) {
				moveFlag = 1;
			} else if (playerPos.x > transform.position.x) {
				moveFlag = 2;
			} 
		}

        if(isChasing && isRange && !isAvoid) {
            Vector3 playerPos = traceTarget.transform.position;

            if (Mathf.Abs(playerPos.x - transform.position.x) < 8.0f)
            {
                moveFlag = 0;
                if (playerPos.x < transform.position.x)
                {
                    sr.flipX = true;
                }
                else if (playerPos.x > transform.position.x)
                {
                    sr.flipX =false;
                }
            }
            else if (playerPos.x < transform.position.x)
            {
                moveFlag = 1;
            }
            else if (playerPos.x > transform.position.x)
            {
                moveFlag = 2;
            }


        }

        if (isAvoid)
        {
            Vector3 playerPos = traceTarget.transform.position;
            

            if (Mathf.Abs(playerPos.x - transform.position.x) < 3.0f)
            {
                if (playerPos.x < transform.position.x)
                {
                    moveFlag = 2;
                }
                else if (playerPos.x > transform.position.x)
                {
                    moveFlag = 1;
                }
                time += Time.deltaTime;
                if(time >= avoidTime)
                {
                    moveFlag = 0;
                }
                if(time >= 3.0f)
                {
                    time = 0;
                }
            }
        }


		//moveFlag로 이동방향 지정
		if (!isAttacking && !isCharging) {
			if (moveFlag == 1) {
				sr.flipX = true;
				moveVelocity = Vector3.left;
				isLeft = true;
                anim.SetBool("isRun", true);
            } else if (moveFlag == 2) {
				sr.flipX = false;
				moveVelocity = Vector3.right;
				isLeft = false;
                anim.SetBool("isRun", true);
            } else if(moveFlag == 0) {
                anim.SetBool("isRun", false);
                moveVelocity = Vector3.zero;
            }
		}


        //이동
        if (!isStop)
        {
            transform.Translate(moveVelocity * moveSpeed * Time.deltaTime);
        }
        else
            anim.SetBool("isRun", false);
    }

	public IEnumerator ChangeMovement(){
		moveFlag = Random.Range (0, 3);

		yield return new WaitForSeconds (3.0f);

		StartCoroutine (ChangeMovement ());
	}

	public IEnumerator Damaged(bool isLeft, int attackType, float power){	//방향, 받은 공격의 타입(Attack Script 참조), 상태이상 정도
		isStop = true;
		switch (attackType) {
		case 0:
			if (isLeft) {
				rid.AddForce (Vector2.left * (power - strength) * 100);
			} else {
				rid.AddForce (Vector2.right * (power - strength) * 100);
			}
			break;	
		case 1:
			rid.AddForce (Vector2.up * (power - strength) * 100);
			break;
		case 2:
			rid.AddForce (Vector2.down * (power - strength) * 100);
			break;
		}
		sr.color = new Color32 (255, 110, 110, 255);
		yield return new WaitForSeconds (0.2f);
		sr.color = new Color32 (255, 255, 255, 255);
        if(!isCharging)
		    isStop = false;
		isDamaged = false;
	}

    public IEnumerator Charge(bool left, Vector2 target)
    {
        isStop = true;

        yield return new WaitForSeconds(1.5f);

        this.target = target;

        if (left)
        {
            chargeLeft = true;
            isCharging = true;
        }
        else
        {
            chargeLeft = false;
            isCharging = true;
        }
        
    }

}
