﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Biter_2 : MonoBehaviour {		//플레이어와의 충돌을 감지하기 위한 스크립트

	EnemyBase eb;
	Attack at;
	Projectile pj;

	void Start(){
		eb = GetComponentInParent<EnemyBase> ();
	}

	void OnTriggerEnter2D(Collider2D other){
		if (other.CompareTag ("PlayerAttack")) {
			at = other.GetComponent<Attack> ();
			eb.isDamaged = true;
			eb.hp -= at.damage - eb.DEF;
			eb.StartCoroutine (eb.Damaged (at.isLeft, at.ccType, at.power));
			if (at.isRangedAttack)
				Destroy (other.gameObject);
		}

	}
}
