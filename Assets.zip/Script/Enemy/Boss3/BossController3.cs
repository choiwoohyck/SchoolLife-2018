﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossController3 : MonoBehaviour {

    public GameObject bulletModel;

    int pattern = 1;
    int phase = 1;
    int attackCount;
    int pattern1Count = 0;
    int pattern2Count = 0;
    int pattern4Count = 0;
    int pattern6Count = 0;

    bool phaseChange = false;


    EnemyBase eb;

    UIController uCon;
    CameraController cCon;

    float attackDelay = 0.0f;

    public Sprite type;

	// Use this for initialization
	void Start () {
        eb = GetComponent<EnemyBase>();
        uCon = GameObject.Find("UIController").GetComponent<UIController>();
        cCon = GameObject.Find("Main Camera").GetComponent<CameraController>();

        uCon.bossEmpty.gameObject.SetActive(true);
        uCon.bossFull.gameObject.SetActive(true);
    }

    // Update is called once per frame
    void Update()
    {
        attackDelay += Time.deltaTime;
        uCon.bossFull.fillAmount = eb.hp / eb.startHp;
        if (eb.hp <= 0)
        {
            StartCoroutine(Dead());
        }
        if (eb.hp >= 50)
        {
            phase = 1;
        }
        else if (eb.hp < 50 && !phaseChange)
        {
            phaseChange = true;
            phase = 2;
            pattern = 4;
            GetComponent<SpriteRenderer>().color = new Color32(255, 160, 160, 255);
            GetComponent<SpriteRenderer>().sprite = type;
        }

        if (phase == 1)
        {

            if (pattern == 1 && attackDelay >= 2)
            {
                GameObject[] b = new GameObject[20];
                int randomCase = Random.Range(0, 3);
                for (int i = 0; i < 20; i++)
                {
                    b[i] = Instantiate(bulletModel, transform.position, Quaternion.identity);
                    b[i].GetComponent<BulletController3>().pattern = 1;
                    b[i].GetComponent<BulletController3>().moveAngle = i * 18;
                    b[i].GetComponent<BulletController3>().randomCase = randomCase;
                }


                attackDelay = 0;

                if (++pattern1Count >= 3)
                {
                    pattern = 2;
                    pattern1Count = 0;
                }
            }

            if (pattern == 2 && attackDelay >= 0.05f)
            {
                GameObject[] b = new GameObject[4];
                for (int i = 0; i < 4; i++)
                {
                    b[i] = Instantiate(bulletModel, transform.position, Quaternion.identity);
                    b[i].GetComponent<BulletController3>().pattern = 2;
                    if (i == 0)
                        b[i].GetComponent<BulletController3>().moveAngle = 40;
                    if (i == 1)
                        b[i].GetComponent<BulletController3>().moveAngle = 140;
                    if (i == 2)
                        b[i].GetComponent<BulletController3>().moveAngle = -40;
                    if (i == 3)
                        b[i].GetComponent<BulletController3>().moveAngle = -140;

                    b[i].GetComponent<BulletController3>().dirCase = i;
                }

                if (++pattern2Count >= 10)
                {
                    pattern = 3;
                    pattern2Count = 0;
                }

                attackDelay = 0;
            }

            if (pattern == 3 && attackDelay >= 2)
            {
                GameObject[] b = new GameObject[40];
                int randomCase = Random.Range(0, 3);
                for (int i = 0; i < 40; i++)
                {
                    b[i] = Instantiate(bulletModel, transform.position, Quaternion.identity);
                    b[i].GetComponent<BulletController3>().pattern = 3;
                    b[i].GetComponent<BulletController3>().moveAngle = i * 9;

                }


                attackDelay = 0;

                pattern = 1;
            }
        }

        if (phase == 2)
        {

            if (pattern == 4 && attackDelay >= 3)
            {
                GameObject[] b = new GameObject[40];
                for (int i = 0; i < 20; i++)
                {
                    b[i] = Instantiate(bulletModel, transform.position, Quaternion.identity);
                    b[i].GetComponent<BulletController3>().pattern = 4;
                    b[i].GetComponent<BulletController3>().moveAngle = i * 18;

                }

                if (++pattern4Count >= 3)
                {
                    pattern = 5;
                    pattern4Count = 0;
                }

                attackDelay = 0;

            }

            if (pattern == 5 && attackDelay >= 3)
            {
                GameObject[] b = new GameObject[20];
                for (int i = 0; i < 20; i++)
                {
                    b[i] = Instantiate(bulletModel, new Vector3(Random.Range(-15.0f, 20.0f), Random.Range(-4.0f, 20.0f), 0), Quaternion.identity);
                    b[i].GetComponent<BulletController3>().pattern = 5;
                    
                }

                pattern = 6;

                attackDelay = 0;

            }

            if (pattern == 6 && attackDelay >= 1)
            {
                GameObject b = Instantiate(bulletModel, new Vector3(Random.Range(-15.0f, 20.0f), Random.Range(-4.0f, 10.0f), 0), Quaternion.identity);
                b.GetComponent<BulletController3>().pattern = 6;


                if (++pattern6Count >= 10)
                {
                    pattern = 4;
                    pattern6Count = 0;
                }

                attackDelay = 0;

            }
        }
    }

    void OnTriggerEnter2D(Collider2D coll)
    {

        if (coll.CompareTag("PlayerAttack"))
        {
            Attack at;
            at = coll.GetComponent<Attack>();
            eb.isDamaged = true;
            eb.hp -= at.damage - eb.DEF;
            eb.StartCoroutine(eb.Damaged(at.isLeft, at.ccType, at.power));
            if (at.isRangedAttack)
                Destroy(coll.gameObject);
        }
    }

    IEnumerator Dead()
    {
        Transform original = cCon.targetTrans;
        cCon.targetTrans = gameObject.transform;
        yield return new WaitForSeconds(2.0f);
        cCon.targetTrans = original;
        uCon.bossEmpty.gameObject.SetActive(false);
        uCon.bossFull.gameObject.SetActive(false);
        if (eb.haveItem)
        {
            Instantiate(eb.dropItems[UnityEngine.Random.Range(0, eb.dropItems.Length)], transform.position, Quaternion.identity);
        }

        GameObject.Find("GameManager").GetComponent<GameManager>().StartCoroutine(GameObject.Find("GameManager").GetComponent<GameManager>().Next(5));

        Destroy(gameObject);
    }
}
