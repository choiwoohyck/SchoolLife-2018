﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletController3 : MonoBehaviour {

    GameObject player;
    GameObject r;

    PlayerController pCon;


    public GameObject route;
    public int pattern;
    int circleCount = 0;

    public float moveAngle = 0.0f;
    float firstmoveAngle;
    float x;
    float y;
    float moveSpeed = 10.0f;
    float changeTimer = 0.0f;

    public int randomCase = 0;
    public int dirCase = 0;

    bool setRotation = false;
    bool setTarget = false;
    bool destoryRoute = false;

    private float GetAngle(Vector2 obj1, Vector2 obj2)
    {
        float rad = Mathf.Atan2(obj1.y - obj2.y, obj1.x - obj2.x);
        float degree = rad * Mathf.Rad2Deg;

        return degree + 180.0f;
    }

    // Use this for initialization
    void Start () {
        x = transform.position.x;
        y = transform.position.y;

        firstmoveAngle = moveAngle;

        if (pattern == 2)
            y += 5.0f;

        if (randomCase == 0 && pattern == 1)
        {
            firstmoveAngle *= -1;
        }

        if ( pattern !=5 )
         moveAngle *= Mathf.Deg2Rad;

        player = GameObject.Find("Player");
        pCon = GameObject.Find("Player").GetComponent<PlayerController>();

    }
	
	// Update is called once per frame
	void Update () {
        if (pattern == 1)
        {
            if (circleCount < 2)
            {
                moveAngle += Time.deltaTime * moveSpeed;
                x += Mathf.Cos(moveAngle) * moveSpeed * Time.deltaTime;
                y += Mathf.Sin(moveAngle) * moveSpeed * Time.deltaTime;
            }

            else
            {
                if (randomCase != 2)
                {
                    x += Mathf.Cos(firstmoveAngle * Mathf.Deg2Rad) * moveSpeed * Time.deltaTime;
                    y += Mathf.Sin(firstmoveAngle * Mathf.Deg2Rad) * moveSpeed * Time.deltaTime;
                }
                else
                {
                    x -= Mathf.Cos(firstmoveAngle * Mathf.Deg2Rad) * moveSpeed * Time.deltaTime;
                    y -= Mathf.Sin(firstmoveAngle * Mathf.Deg2Rad) * moveSpeed * Time.deltaTime;
                }
            }

            if (moveAngle >= 360 * Mathf.Deg2Rad)
            {
                moveAngle = 0;
                circleCount++;
            }



            Vector2 moveMent = new Vector2(x, y);
            transform.position = moveMent;
        }

        if (pattern == 2)
        {
          


           changeTimer += Time.deltaTime;

            if (dirCase == 1)
            {
                Debug.Log(moveAngle + " " + 160 * Mathf.Deg2Rad);
            }

            if (changeTimer >= 0.3f)
            {
                if (dirCase == 0 && moveAngle >= Mathf.Deg2Rad * -60)
                    moveAngle -= 20.0f * Time.deltaTime;

                if (dirCase == 1 && moveAngle <= Mathf.Deg2Rad * 240)
                    moveAngle += 20.0f * Time.deltaTime;

            }

            x += Mathf.Cos(moveAngle) * moveSpeed * Time.deltaTime;
            y += Mathf.Sin(moveAngle) * moveSpeed * Time.deltaTime;

            Vector2 moveMent = new Vector2(x, y);
            transform.position = moveMent;
        }

        if (pattern == 3)
        {
            changeTimer += Time.deltaTime;

            if (changeTimer >= 0.8f && !setRotation)
            {
                moveAngle += 20.0f * Time.deltaTime;
            }

            if (changeTimer >= 1.3f)
            {
                if (!setRotation)
                {
                    moveAngle = Random.Range(-180, 180) * Mathf.Deg2Rad;
                    setRotation = true;
                }
            }

            x += Mathf.Cos(moveAngle) * moveSpeed * Time.deltaTime;
            y += Mathf.Sin(moveAngle) * moveSpeed * Time.deltaTime;
            Vector2 moveMent = new Vector2(x, y);
            transform.position = moveMent;
        }

        if (pattern == 4)
        {
            changeTimer += Time.deltaTime;

            if (changeTimer <= 0.8f)
            {
                x += Mathf.Cos(moveAngle) * 12.0f * Time.deltaTime;
                y += Mathf.Sin(moveAngle) * 12.0f * Time.deltaTime;
            }

            if (changeTimer >= 0.8f)
            {
                x -= Mathf.Cos(moveAngle) * 12.0f * Time.deltaTime;
                y -= Mathf.Sin(moveAngle) * 12.0f * Time.deltaTime;
            }

            Vector2 moveMent = new Vector2(x, y);
            transform.position = moveMent;
        }

        if (pattern == 5)
        {
            changeTimer += Time.deltaTime;

            if (changeTimer <= 0.2f)
            {

                if (!setTarget)
                { 
                    Vector2 p = player.transform.position - transform.position;
                    moveAngle = Mathf.Atan2(p.y, p.x);
                    setTarget = true;
                }

            }

            else
            {
           
                x += Mathf.Cos(moveAngle) * moveSpeed * Time.deltaTime;
                y += Mathf.Sin(moveAngle) * moveSpeed * Time.deltaTime;
                Vector2 moveMent = new Vector2(x, y);
                transform.position = moveMent;
            }


            if (transform.position.x >= 20.0f || transform.position.x <= -15.0f || transform.position.y <= -6.0f || transform.position.y >= 20.0f)
                Destroy(gameObject);


        }

        if (pattern == 6)
        {
            changeTimer += Time.deltaTime;

            if (changeTimer <= 2.0f)
            {
                
                if (!setTarget)
                {
                    Vector2 p = player.transform.position - transform.position;
                    moveAngle = Mathf.Atan2(p.y, p.x);
                    r = Instantiate(route, transform.position, Quaternion.identity);
                    r.transform.Rotate(0, 0, GetAngle(transform.position, player.transform.position));
                    setTarget = true;
                }

            }

            else
            {
                if (!destoryRoute)
                {
                    Destroy(r.gameObject);
                    destoryRoute = true;
                }
                x += Mathf.Cos(moveAngle) *  20.0f * Time.deltaTime;
                y += Mathf.Sin(moveAngle) * 20.0f * Time.deltaTime;
                Vector2 moveMent = new Vector2(x, y);
                transform.position = moveMent;
            }


            if (transform.position.x >= 20.0f || transform.position.x <= -15.0f || transform.position.y <= -6.0f || transform.position.y >= 20.0f)
                Destroy(gameObject);
        }
    }

    void OnBecameInvisible()
    {
       if (pattern != 5) 
       Destroy(gameObject);
    }

    void OnTriggerEnter2D(Collider2D coll)
    {
        if (coll.CompareTag("Player"))
        {
            pCon.Attacked(2);
            if (!(pCon.isDashing || pCon.isInv))
                Destroy(gameObject);
        }
    }
}




