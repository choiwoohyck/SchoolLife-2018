﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossShadow : MonoBehaviour {

    public GameObject owner;
    GameObject player;
    float landingTimer;


	// Use this for initialization
	void Start () {
        player = GameObject.Find("Player");
	}
	
	// Update is called once per frame
	void Update () {

        landingTimer += Time.deltaTime;

        Vector2 dir = (player.transform.position - transform.position).normalized;
        
        float distance = Vector2.Distance(player.transform.position , transform.position);
        
        transform.position = new Vector2(transform.position.x + (dir.x * 3.8f * Time.deltaTime), transform.position.y);

        if (landingTimer >= 2.0f)
        {
            owner.GetComponent<BossController>().isLanding = true;
            owner.GetComponent<BossController>().landingPosx = transform.position.x;
            Destroy(gameObject);
        }

        
	}
}
