﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletController : MonoBehaviour {

    public float moveAngle;
    public float regulateSpeed;
    public float damage = 1;

    PlayerController pCon;

    public Sprite[] sprites = new Sprite[4];

    float x;
    float y;

	// Use this for initialization
	void Start () {
        x = transform.position.x;
        y = transform.position.y;

        moveAngle *= Mathf.Deg2Rad;
        pCon = GameObject.Find("Player").GetComponent<PlayerController>();
        GetComponent<SpriteRenderer>().sprite = sprites[UnityEngine.Random.Range(0, 4)];
    }

    // Update is called once per frame
    void Update () {

        x += Mathf.Cos(moveAngle) * regulateSpeed;
        y += Mathf.Sin(moveAngle) * regulateSpeed;

        Vector3 movement = new Vector2(x,y);
        transform.position = movement;       
    }

    void OnBecameInvisible()
    {
        Destroy(gameObject);
    }

    void OnTriggerEnter2D(Collider2D coll)
    {
        if (coll.CompareTag("Player"))
        {
            pCon.Attacked(damage);
            if(!(pCon.isDashing || pCon.isInv))
                Destroy(gameObject);
        }   
    }
}
