﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using System;
public class BossController : MonoBehaviour {

    // Use this for initialization

    int attackCount = 0;
    int pattern = 4;
    int pattern2Count = 0;
    int shockWaveCount = 0;

    float attackDelay;
    float pattern2AttackDelay;
    float landingSpeed = 30.0f;
    public float landingPosx;
    float shockWaveTimer = 0.0f;
    float shockWavePosX;

    bool isShadowCreate = false;
    bool isP5Running = false;
    public bool isLanding = false;

    GameObject player;

    Rigidbody2D rid;

    EnemyBase eb;

    UIController uCon;
    CameraController cCon;
    PlayerController pCon;

    public GameObject bulletModel;
    public GameObject shadow;
    public GameObject shockWave;

    

    void Start() {
        player = GameObject.Find("Player");
        pCon = player.GetComponent<PlayerController>();
        eb = GetComponent<EnemyBase>();
        rid = GetComponent<Rigidbody2D>();
        uCon = GameObject.Find("UIController").GetComponent<UIController>();
        cCon = GameObject.Find("Main Camera").GetComponent<CameraController>();

        uCon.bossEmpty.gameObject.SetActive(true);
        uCon.bossFull.gameObject.SetActive(true);

        
        
    }

    // Update is called once per frame
    void Update() {
        uCon.bossFull.fillAmount = eb.hp / eb.startHp;
        if (eb.hp <= 0)
        {
            StartCoroutine(Dead());
        }
        else
        {
            attackDelay += Time.deltaTime;

            Debug.Log(isLanding);
            if (attackCount != 0)
            {
                if (attackCount % 3 == 0)
                    pattern = 2;

                else if (attackCount % 7 == 0)
                    pattern = 3;

                else if (attackCount % 10 == 0)
                {
                    if (!isP5Running)
                        pattern = 4;
                }
                else
                    pattern = 1;
            }
            else
            {
                pattern = 1;
            }

            if (attackDelay >= 1.0f && pattern == 1)
            {
                GameObject bullet = Instantiate(bulletModel, transform.position, Quaternion.identity);
                Vector2 p = player.transform.position - transform.position;
                bullet.GetComponent<BulletController>().moveAngle = Mathf.Atan2(p.y, p.x) * Mathf.Rad2Deg;
                bullet.GetComponent<BulletController>().regulateSpeed = 0.2f;

                attackDelay = 0;

                attackCount++;
            }

            if (attackDelay >= 3.0f && pattern == 2)
            {
                GameObject[] bullet = new GameObject[20];

                for (int i = 0; i < 20; i++)
                {
                    bullet[i] = Instantiate(bulletModel, transform.position, Quaternion.identity);
                    bullet[i].GetComponent<BulletController>().moveAngle = i * 18;
                    bullet[i].GetComponent<BulletController>().regulateSpeed = 0.07f;
                }


                attackDelay = 0;
                attackCount++;

            }

            if (pattern2Count <= 0)
                pattern2AttackDelay = 3.0f;
            else
                pattern2AttackDelay = 0.06f;


            if (attackDelay >= pattern2AttackDelay && pattern2Count <= 15 && pattern == 3)
            {
                GameObject bullet = Instantiate(bulletModel, transform.position, Quaternion.identity);
                Vector2 p = player.transform.position - transform.position;
                bullet.GetComponent<BulletController>().moveAngle = Mathf.Atan2(p.y, p.x) * Mathf.Rad2Deg;
                bullet.GetComponent<BulletController>().regulateSpeed = 0.25f;

                pattern2Count++;

                attackDelay = 0;

            }

            if (pattern2Count == 13)
            {
                attackCount++;
                pattern2Count = 0;
            }


            if (pattern == 4)
            {
                float posY = transform.position.y;

                if (posY <= player.GetComponent<PlayerController>().mapPosY * 60 + 7 && !isLanding)
                    transform.Translate(Vector2.up * 5.0f * Time.deltaTime);
                else
                {
                    Vector2 fixedPos = new Vector2(transform.position.x, player.GetComponent<PlayerController>().mapPosY * 60 + 7);

                    if (!isLanding)
                        transform.position = fixedPos;

                    if (!isShadowCreate)
                    {
                        Vector2 playerPos = player.transform.position;
                        GameObject s = Instantiate(shadow, new Vector2(player.GetComponent<PlayerController>().mapPosX * 60, player.GetComponent<PlayerController>().mapPosY * 60 - 5.6f), Quaternion.identity);
                        s.GetComponent<BossShadow>().owner = gameObject;
                        isShadowCreate = true;

                    }

                    if (isLanding)
                    {
                        landingSpeed += 3.0f * Time.deltaTime;
                        Vector2 fixedPos2 = new Vector2(landingPosx, player.GetComponent<PlayerController>().mapPosY * 60 + 7);
                        transform.position = new Vector2(landingPosx, transform.position.y);

                        if (posY >= player.GetComponent<PlayerController>().mapPosY * 60 -4.1f)
                        {
                            transform.Translate(Vector2.down * landingSpeed * Time.deltaTime);
                        }
                        else
                        {
                            transform.position = new Vector2(transform.position.x, player.GetComponent<PlayerController>().mapPosY * 60 -4.1f);
                            isLanding = false;
                            isShadowCreate = false;
                            pattern = 5;
                        }
                    }
                }
            }

            if (pattern == 5)
            {
                isP5Running = true;
                shockWaveTimer += Time.deltaTime;
                if (shockWaveTimer >= 0.2f && shockWaveCount <= 10)
                {
                    if (shockWaveCount == 0)
                    {
                        GameObject s = Instantiate(shockWave, transform.position, Quaternion.identity);
                        shockWaveCount++;
                    }

                    else
                    {
                        GameObject[] s = new GameObject[2];
                        for (int i = 0; i < 2; i++)
                        {
                            if (i == 0)
                                shockWavePosX = transform.position.x - shockWaveCount;
                            else
                                shockWavePosX = transform.position.x + shockWaveCount;

                            s[i] = Instantiate(shockWave, new Vector2(shockWavePosX, transform.position.y), Quaternion.identity);

                        }
                        shockWaveCount++;
                        shockWaveTimer = 0;

                    }

                    shockWaveTimer = 0;
                }
                else if (shockWaveCount > 10)
                {
                    isP5Running = false;
                    attackCount++;
                    shockWaveCount = 0;
                }



            }
        }
    }

    void OnTriggerEnter2D(Collider2D coll)
    {
        if (coll.CompareTag("Player") && isLanding)
        {
            player.GetComponent<PlayerController>().Attacked(3);

        }
        if (coll.CompareTag("PlayerAttack"))
        {
            Attack at;
            at = coll.GetComponent<Attack>();
            eb.isDamaged = true;
            eb.hp -= at.damage - eb.DEF;
            eb.StartCoroutine(eb.Damaged(at.isLeft, at.ccType, at.power));
            if (at.isRangedAttack)
                Destroy(coll.gameObject);
        }
    }

    IEnumerator Dead()
    {
        Transform original = cCon.targetTrans;
        cCon.targetTrans = gameObject.transform;
        yield return new WaitForSeconds(2.0f);
        cCon.targetTrans = original;
        uCon.bossEmpty.gameObject.SetActive(false);
        uCon.bossFull.gameObject.SetActive(false);
        if (eb.haveItem)
        {
            Instantiate(eb.dropItems[UnityEngine.Random.Range(0, eb.dropItems.Length)], transform.position, Quaternion.identity);
        }
       
        GameObject.Find("GameManager").GetComponent<GameManager>().StartCoroutine(GameObject.Find("GameManager").GetComponent<GameManager>().Next(3));

        Destroy(gameObject);

    }


}

