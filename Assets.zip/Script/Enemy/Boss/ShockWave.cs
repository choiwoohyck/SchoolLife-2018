﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShockWave : MonoBehaviour {

    // Use this for initialization

    float lifeTime = 0.0f;
    float colorA = 1.0f;

    GameObject player;

    void Start () {

        player = GameObject.Find("Player");

    }
	
	// Update is called once per frame
	void Update () {
        lifeTime += Time.deltaTime;

        if (lifeTime >= 0.2f)
        {
            colorA -= Time.deltaTime * 6.0f;
            GetComponent<SpriteRenderer>().color = new Color(0, 0, colorA);
        }

        if (lifeTime >= 0.3f)
        {
            Destroy(gameObject);
        }
	}

    void OnTriggerEnter2D(Collider2D coll)
    {
        if (coll.CompareTag("Player"))
        {
            player.GetComponent<PlayerController>().Attacked(3);
            Destroy(gameObject);

        }
    }
}
