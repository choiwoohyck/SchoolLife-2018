﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChaseAI : MonoBehaviour {

	public GameObject enemy;
	EnemyBase e;
	void Start(){
		e = enemy.GetComponent<EnemyBase> ();
	}

	void OnTriggerEnter2D(Collider2D other){
		if (other.CompareTag ("Player")) {
			e.traceTarget = other.gameObject;
			GetComponent<CircleCollider2D> ().radius = 3.0f;
            e.moveSpeed += 1.0f;
			e.StopCoroutine (e.ChangeMovement ());
		}
	}

	void OnTriggerStay2D(Collider2D other){
		if (other.CompareTag ("Player")) {
			e.isChasing = true;
		}
	}

	void OnTriggerExit2D(Collider2D other){
		if (other.CompareTag ("Player")) {
			e.isChasing = false;
			GetComponent<CircleCollider2D> ().radius = 1.5f;
            e.moveSpeed -= 1.0f;
			e.StartCoroutine (e.ChangeMovement ());
		}
	}
}
