﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AvoidAI : MonoBehaviour
{

    public GameObject enemy;
    EnemyBase e;
    void Start()
    {
        e = enemy.GetComponent<EnemyBase>();
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            e.traceTarget = other.gameObject;
            e.StopCoroutine(e.ChangeMovement());
        }
    }

    void OnTriggerStay2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            e.isAvoid= true;
        }
    }

    void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            e.isAvoid = false;
            e.StartCoroutine(e.ChangeMovement());
        }
    }
}
