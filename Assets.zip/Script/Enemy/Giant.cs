﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Giant : MonoBehaviour
{

    EnemyBase eb; //Entity Base (EnemyBase스크립트)
    float attackTime = 3.0f;
    float attackDelay = 2.5f;   //공격간 딜레이 (공격 속도)
    float chargeAttackDelay = 10.0f;
    float attackSpeed = 0.7f;   //공격 범위 표시 후 실제공격 전 까지의 시간
    float dummyRemoveTime = 0.3f; //공격 더미의 파괴 시간
    bool attackStart = false;
    bool dashAttack = false;
    bool canCharge = true;

    bool isAttacking = false;

    bool isPlayerLeft = false;
    Vector2 target;

    public GameObject attackDummy;
    public GameObject chargeDummy;
    void Start()
    {
        eb = GetComponentInParent<EnemyBase>();
    }

    void Update()
    {
        if (attackStart == true)
        {
            if (attackTime <= attackDelay)
            {     //attackSpeed초 마다 공격
                attackTime += Time.deltaTime;
            }
            else
            {
                attackTime = 0.0f;
                //공격(
                if (eb.isLeft)
                {
                    attackDummy.transform.position = new Vector2(transform.position.x - 2f, transform.position.y + 0.3f);
                    attackDummy.SetActive(true);
                }
                else
                {
                    attackDummy.transform.position = new Vector2(transform.position.x + 2f, transform.position.y + 0.3f);
                    attackDummy.SetActive(true);
                }
                eb.isAttacking = true;
                attackDummy.GetComponent<EnemyAttack>().StartCoroutine(attackDummy.GetComponent<EnemyAttack>().DesTimer(eb.isLeft, attackSpeed, dummyRemoveTime));
                StartCoroutine(StopToAttack()); //공격이 끝날 때 까지 정지
                //)

            }
        }
        if (dashAttack == true && canCharge == true)
        {
            canCharge = false;
            isAttacking = true;
            dashAttack = false;
            eb.StartCoroutine(eb.Charge(isPlayerLeft, target));
            StartCoroutine(ChargeAttackCooldown());
        }

        if (eb.isCharging)
        {
            chargeDummy.SetActive(true);
        }
        else
        {
            chargeDummy.SetActive(false);
        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {

        if (other.CompareTag("Player"))
        {
            if (canCharge)
                eb.isStop = true;
            else if (!canCharge && Mathf.Abs(other.gameObject.transform.position.x - transform.position.x) < 3)
                eb.isStop = true;
        }
    }

    void OnTriggerStay2D(Collider2D other)
    {
        if (other.CompareTag("Player") && !eb.isDamaged)
        {
            if (Mathf.Abs(other.gameObject.transform.position.x - transform.position.x) < 4 && !isAttacking)
                attackStart = true;
            else if(Mathf.Abs(other.gameObject.transform.position.x - transform.position.x) >= 4 && !canCharge)
            {
                attackStart = false;
            }
            else if (Mathf.Abs(other.gameObject.transform.position.x - transform.position.x) > 4 && canCharge)
            {
                if (other.gameObject.transform.position.x - transform.position.x < 0)
                    isPlayerLeft = true;
                else
                    isPlayerLeft = false;
                target = other.gameObject.transform.position;
                dashAttack = true;
                isAttacking = true;
            }
        }
    }

    void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            if(canCharge)
                eb.isStop = false;
            attackStart = false;
        }
    }

    public IEnumerator StopToAttack()
    {   //공격이 끝날 때 까지 정지하기 위한 코루틴
        
        yield return new WaitForSeconds(attackSpeed + dummyRemoveTime);
        eb.isStop = false;
        eb.isAttacking = false;
    }
    IEnumerator ChargeAttackCooldown()
    {
        isAttacking = false;
        yield return new WaitForSeconds(chargeAttackDelay);
        canCharge = true;
    }



}
