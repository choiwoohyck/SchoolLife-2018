﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MapGenerator : MonoBehaviour
{
    public int floor = 1;

    public GameObject[,] roomObject;
    public GameObject[] roomInst;
    public GameObject startRoom;
    public GameObject store;
    public GameObject resultRoom;
    public GameObject bossRoom;

    Room[,] rooms;

    int stairPos;   //계단의 위치
    int bossRoomX;  //보스룸 x좌표
    int storeY;
    int storeX;
    int resultY;
    int resultX;

    bool equals = false;

    void Start()
    {
        roomObject = new GameObject[4, 5];      //4층, 한 층당 다섯개의 방
        rooms = new Room[4, 5];
        
        resultX = Random.Range(0, 5);
        storeX = Random.Range(0, 5);
        while (resultX == storeX)
        {
            storeX = Random.Range(0, 5);
        }
        storeY = 2;
        resultY = 1;

        bossRoomX = 4;

        for (int i = 0; i < 4; i++)
        {
            for (int j = 0; j < 5; j++)
            {
                if ((i == 0) && (j == 0))
                    roomObject[i, j] = Instantiate(startRoom, new Vector2(j * 60, i * 60), Quaternion.identity);
                else if ((i == resultY) && (j == resultX))
                    roomObject[i, j] = Instantiate(resultRoom, new Vector2(j * 60, i * 60), Quaternion.identity);
                else if ((i == storeY) && (j == storeX))
                    roomObject[i, j] = Instantiate(store, new Vector2(j * 60, i * 60), Quaternion.identity);
                else if ((i == 3) && (j == 4))
                    roomObject[i, j] = Instantiate(bossRoom, new Vector2(j * 60, i * 60), Quaternion.identity);
                else
                    roomObject[i, j] = Instantiate(roomInst[Random.Range(0, roomInst.Length)], new Vector2(j * 60, i * 60), Quaternion.identity);
            }
        }
        CreateRooms();
    }


    void Update()
    {


    }

    void CreateRooms()
    {
        for (int i = 0; i < 4; i++)
        {
            for (int j = 0; j < 5; j++)
            {

                rooms[i, j] = roomObject[i, j].GetComponent<Room>();

                if (j == 0)
                {
                    rooms[i, j].doorRight = true;
                    rooms[i, j].rightRoom = roomObject[i, j + 1];
                }
                else if (j == 4)
                {
                    rooms[i, j].doorLeft = true;
                    rooms[i, j].leftRoom = roomObject[i, j - 1];
                }
                else
                {
                    rooms[i, j].doorLeft = true;
                    rooms[i, j].doorRight = true;
                    rooms[i, j].leftRoom = roomObject[i, j - 1];
                    rooms[i, j].rightRoom = roomObject[i, j + 1];
                }
                rooms[i, j].CheckDoor();
            }

            if (i == 0)
            {
                if (storeY == 1)
                {
                    while (stairPos == storeX || (stairPos == 0))
                        stairPos = Random.Range(1, 5);
                    rooms[i, stairPos].doorUp = true;
                }
                else if (resultY == 1)
                {
                    while ((stairPos == resultX) || (stairPos == 0))
                        stairPos = Random.Range(1, 5);
                    rooms[i, stairPos].doorUp = true;
                }
                else
                    rooms[i, stairPos = Random.Range(1, 5)].doorUp = true;
                rooms[i, stairPos].upRoom = roomObject[i + 1, stairPos];
                rooms[i, stairPos].CheckDoor();
            }
            else if (i != 3)
            {
                rooms[i, stairPos].doorBot = true;
                rooms[i, stairPos].botRoom = roomObject[i - 1, stairPos];
                rooms[i, stairPos].CheckDoor();
                if (i == 2)
                    rooms[i, stairPos = Random.Range(0, 4)].doorUp = true;
                else if (storeY == 2)
                {
                    while (stairPos == storeX)
                        stairPos = Random.Range(0, 5);
                    rooms[i, stairPos].doorUp = true;
                }
                else if (resultY == 2)
                {
                    while (stairPos == resultX)
                        stairPos = Random.Range(0, 5);
                    rooms[i, stairPos].doorUp = true;
                }
                else
                    rooms[i, stairPos = Random.Range(0, 5)].doorUp = true;

                rooms[i, stairPos].upRoom = roomObject[i + 1, stairPos];
                rooms[i, stairPos].CheckDoor();
            }
            if (i == 3)
            {
                rooms[i, stairPos].doorBot = true;
                rooms[i, stairPos].botRoom = roomObject[i - 1, stairPos];
                rooms[i, stairPos].CheckDoor();
            }
        }
    }
}