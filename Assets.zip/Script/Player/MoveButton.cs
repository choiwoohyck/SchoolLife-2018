﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class MoveButton : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler, IPointerDownHandler{

    public bool isLeft = false;
    public bool isJumpButton = false;
    public bool isMoveButton = false;
    public bool isChangeButton = false;
    public bool isDashButton = false;

    bool isButtonDown = false;
    bool isButtonEnter = false;

    public GameObject player;
    PlayerController pCon;  


	void Start () {
        pCon = player.GetComponent<PlayerController>(); 
	}

	void Update () {
        if (isMoveButton)
        {
            if (isButtonEnter)
            {
                if (isLeft)
                    pCon.moveLeft = true;
                else
                    pCon.moveRight = true;
            }
            else
            {
                if (isLeft)
                    pCon.moveLeft = false;
                else
                    pCon.moveRight = false;
            }
        }
   
        else if (isJumpButton)
        {
            if (isButtonDown)
            {
                pCon.jump = true;
                isButtonDown = false;
            }
            else
            {
                pCon.jump = false;
            }
        }

        else if (isChangeButton)
        {
            if (isButtonDown)
            {
                pCon.change = true;
                isButtonDown = false;
            }
            else
            {
                pCon.change = false;
            }
        }

        else if (isDashButton)
        {
            if (isButtonDown)
            {
                pCon.dash = true;
                isButtonDown = false;
            }
            else
            {
                pCon.dash = false;
            }
        }
        
	}

    public void OnPointerEnter(PointerEventData ped)
    {
        isButtonEnter = true;
    }

    public void OnPointerExit(PointerEventData ped)
    {
        isButtonEnter = false;
    }

    public void OnPointerDown(PointerEventData ped)
    {
        isButtonDown = true;
    }

}
