﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Weapon : MonoBehaviour {

	GameObject player;
    public GameObject hand;
	PlayerController pCon;
    public GameObject projectile; //원거리 무기일경우에 발사체

    public int weaponID;
    public float damage = 0;
    public float attackSpeed = 0;	//공격속도
    public int attackType = 0;

    bool isAttack = false;

	void Start () {
		pCon = GameObject.Find("Player").GetComponent<PlayerController> ();
        hand = GameObject.Find("Hand");
	}

	void Update () {
        if (!isAttack)
        {
            if(attackType == 0)
                transform.position = new Vector2(hand.transform.position.x, hand.transform.position.y + 0.8f);
            else
                transform.position = new Vector2(hand.transform.position.x, hand.transform.position.y);
        }
        else
        {
            if(attackType == 0)
            {
                transform.position = new Vector2(hand.transform.position.x, hand.transform.position.y);

            }
        }
	}

    public void WeaponAttack()
    {
        StartCoroutine(Atk());
    }

    public void Reset()
    {
        pCon = GameObject.Find("Player").GetComponent<PlayerController>();
        hand = GameObject.Find("Hand");
        transform.position = new Vector2(hand.transform.position.x, hand.transform.position.y + 1);
    }

    IEnumerator Atk()
    {
        isAttack = true;
        if (pCon.isLeft)
        {
            transform.RotateAround(hand.transform.position, new Vector3(0, 0, 1), 120.0f);
            yield return new WaitForSeconds(0.2f);
            transform.RotateAround(hand.transform.position, new Vector3(0, 0, -1), 120.0f);
        }
        else
        {
            transform.RotateAround(hand.transform.position, new Vector3(0, 0, -1), 120.0f);
            yield return new WaitForSeconds(0.2f);
            transform.RotateAround(hand.transform.position, new Vector3(0, 0, 1), 120.0f);
        }
        isAttack = false;

    }
}
