﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Projectile : MonoBehaviour {

    public Vector3 targetPos;

    public float speed = 20.0f;

    void Start() {
        StartCoroutine(DestroyThis());
        transform.Rotate(0, 0, GetAngle(transform.position, targetPos));
    }

    // Update is called once per frame
    void FixedUpdate() {
        transform.Translate(Vector2.right * speed * Time.deltaTime);
    }

    IEnumerator DestroyThis() {
        yield return new WaitForSeconds(4.0f);
        Destroy(gameObject);
    }

    private float GetAngle(Vector2 obj1, Vector2 obj2)
    {
        float rad = Mathf.Atan2(obj1.y - obj2.y, obj1.x - obj2.x);
        float degree = rad * Mathf.Rad2Deg;

        return degree + 180.0f;
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("ground") || other.CompareTag("wall"))
        {
            Destroy(gameObject);
        }
    }
}
