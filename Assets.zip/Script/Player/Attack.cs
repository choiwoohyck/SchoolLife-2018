﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Attack : MonoBehaviour {

	PlayerController pCon;

	public bool isRangedAttack = false; //원거리 공격인지 여부
    public bool isTickDamage = false;   //틱데미지 (불 전용)
    public float damage = 0;
	public bool isLeft = false;
	public int ccType = 0; //0 = 작은넉백(기본), 1 = 띄우기 , 2 = 찍기....(추가)
	public float power = 0;
	public int spriteType = 0;

    float time = 1;

	void Awake(){
        pCon = GameObject.Find("Player").GetComponent<PlayerController>();
	}

    void Start()
    {
        damage += pCon.totalDamage;
    }

	void Update(){
		if (!isRangedAttack && pCon.attackType == 0) {
			switch (spriteType) {
			case 0:
				if (isLeft) {
					GetComponent<SpriteRenderer> ().flipX = false;
				} else
					GetComponent<SpriteRenderer> ().flipX = true;
				break;
			case 1:
				if (isLeft) {
					GetComponent<SpriteRenderer> ().flipX = true;
				} else
					GetComponent<SpriteRenderer> ().flipX = false;
				break;
			}
			if (isLeft) {
				transform.Translate (Vector3.left * 0.01f);
			} else {
				transform.Translate (Vector3.right * 0.01f);
			}
		}

        if (isTickDamage)
        {
            time += Time.deltaTime;
            if(time >= 1.0f)
            {

                GetComponent<BoxCollider2D>().enabled = true;
                time = 0;
            }
            else
            {
                GetComponent<BoxCollider2D>().enabled = false;
            }
        }
	}
	public IEnumerator DesTimer(){
        GetComponent<SpriteRenderer>().enabled = true;
        isLeft = pCon.isLeft;
		yield return new WaitForSeconds (0.15f);
		GetComponent<SpriteRenderer> ().enabled = false;
		gameObject.SetActive (false);
	}

    public IEnumerator FireOn()
    {
        yield return new WaitForSeconds(3.5f);
        Destroy(gameObject);
    }


}
