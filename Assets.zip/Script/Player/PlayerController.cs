﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour {


    public float moveSpeed = 5.0f;		//이동속도
    public float dashSpeed = 3.0f;	//구르기 속도
	public float hp = 10.0f;			//체력
	public float maxHp = 10.0f;
	private float jumpSize = 680.0f;	//점프 크기
	public float attackSpeed = 0.8f;	//공격속도
	private float attackSpeed_Range = 0.7f; //원거리 공격속도
    public float damage;

    public float totalDamage;
    public float totalAttackSpeed;
    public float totalAttackSpeed_Range;

    public bool moveLeft = false;
    public bool moveRight = false;
    public bool jump = false;           //버튼 관련
    public bool dash = false;       
    public bool change = false;


    public bool isLeft = false;
    bool isMove = false;
    public bool isDashing = false;
	bool dashCooldown = false;
	bool isJumping = false;
	public bool isInv = false; //피격시 무적(Invincibility)


    public int mapPosX = 0; //맵 상에서의 플레이어의 위치
    public int mapPosY = 0;

	//공격 관련
	bool isAttack = false;			//근거리 공격중
	bool isAttack_Range = false;	//원거리 공격중
	public int attackType = 9;		//공격의 종류 (0 = 검, 1 = 투사체 .... 9 = 무기없음)
	int noOfClicks = 0;
	float lastAttackTime = 0;
	float maxComboDelay = 0.8f;	//콤보 간 최대 간격
	bool isCharged = false;		//충전 됨
	bool isChanged = false;		//무기 변경
	bool isChangeCooldown = false;
	float changeTime = 0.0f;

    //무기 관련
    public int weaponID = 0;   //현재 장착중인 무기의 ID값   (0 = empty, 1 = pencil, 2 = eraser...
    public int weaponID_1 = 0; //1번 슬롯에 장착중인 무기의 ID값
    public int weaponID_2 = 0; //2번 슬롯에 장착중인 무기의 ID값
    bool isEquip = false;      //무기 획득시 바로 장착하는지 여부

    //아이템
    public int[] pickedItems = new int[10]; //가지고있는 아이템의 ID값을 넣는 배열
    public int items = 0;       //가지고있는 아이템 수

    private float dashTime = 0.0f;
    public float dashLength = 0.1f;
	private float chargeTime = 0.0f;
    public bool load = false;
    
	SpriteRenderer sr;
	Rigidbody2D rid;
	Animator anim;
	UIController ui;
    Weapon wp;
    Weapon wp_slot1;
    Weapon wp_slot2;

	float lastPosition;

	public GameObject uiObj;

	public GameObject[] basicAttackDummy = new GameObject[3];
    public GameObject spearAttackDummy;
	public GameObject projectile;
    public GameObject weapon;     //현재 장착중인 무기
    public GameObject weapon_1;   //1번 슬롯에 장착중인 무기
    public GameObject weapon_2;   //2번 슬롯에 장착중인 무기
    GameObject equipWeapon;       //장착중인 무기
    public GameObject[] weaponItems = new GameObject[3];    //슬롯을 초과하여 무기를 획득할때 현재 착용중인 무기를 뱉어내기 위한 아이템정보
    public GameObject hand;
    public GameObject fire;

    public GameObject afterImage_left;
    public GameObject afterImage_right;

    JoyStick joyStick;
    Vector3 target; //조이스틱 방향

    public GameObject foot;



    void Start () {
		maxHp = hp;
		ui = uiObj.GetComponent<UIController> ();
		sr = GetComponent<SpriteRenderer> ();
		rid = GetComponent<Rigidbody2D> ();
		anim = GetComponent<Animator> ();

        joyStick = GameObject.Find("BackGroundImage").GetComponent<JoyStick>();

        afterImage_left.GetComponent<ParticleSystem>().Stop();
        afterImage_right.GetComponent<ParticleSystem>().Stop();

        if (load)
        {
            Load();
        }

    }

	void FixedUpdate(){
		//캐릭터 이동(

		isMove = false;
		anim.SetBool("isRun", false);

		if (Input.GetKey(KeyCode.A) || moveLeft && !isDashing)
		{
			transform.Translate(Vector3.left * moveSpeed * Time.deltaTime);
			isLeft = true;
			isMove = true;
			sr.flipX = true;
			anim.SetBool("isRun", true);
		}
		if (Input.GetKey(KeyCode.D) || moveRight && !isDashing)
		{
			transform.Translate(Vector3.right * moveSpeed * Time.deltaTime);
			isLeft = false;
			isMove = true;
			sr.flipX = false;
			anim.SetBool("isRun", true);
		}

		//점프(
		if (jump && !isJumping) {
            foot.layer = 15;
			rid.AddForce (Vector2.up * jumpSize);
			isJumping = true;
            anim.SetBool("isJump", true);
		}
		//)

		//대쉬(
		if (dash && !isDashing && isMove)
		{
			if(!dashCooldown)
				isDashing = true;
		}
		if (isDashing && !dashCooldown)
		{
			if (dashTime <= dashLength)//대쉬 시간
			{
				dashTime += Time.deltaTime;
                if (isLeft)
                {
                    transform.Translate(Vector3.left * dashSpeed * Time.deltaTime);
                    afterImage_left.GetComponent<ParticleSystem>().Play();
                }
                else if (!isLeft)
                {
                    transform.Translate(Vector3.right * dashSpeed * Time.deltaTime);
                    afterImage_right.GetComponent<ParticleSystem>().Play();
                }
			}
			else
			{
				dashCooldown = true;
				dashTime = 0;
				isDashing = false;
                afterImage_left.GetComponent<ParticleSystem>().Stop();
                afterImage_right.GetComponent<ParticleSystem>().Stop();
                StartCoroutine (DashTimer ());
			}
		}
		//)


		//Attack Setting(
		basicAttackDummy [0].GetComponent<Attack> ().ccType = 0;
		basicAttackDummy [1].GetComponent<Attack> ().ccType = 0;		//Set CC Type
		basicAttackDummy [2].GetComponent<Attack> ().ccType = 0;

		basicAttackDummy [0].GetComponent<Attack> ().power = 1;
		basicAttackDummy [1].GetComponent<Attack> ().power = 1;				//Set CC Power
		basicAttackDummy [2].GetComponent<Attack> ().power = 2;
		//)
	}

    void Update() {
        hp = Mathf.Clamp(hp, 0, maxHp);
        if (hp <= 0)
        {
            ui.Dead();
        }


        //무기{
        if (weaponID == 0)      //무기없음
        {
            totalDamage = 0;
            attackType = 9;
        }
        else if(weaponID == 2)      //원거리 무기들
        {
            totalDamage = damage + wp.damage;
            totalAttackSpeed_Range = wp.attackSpeed + attackSpeed_Range;
            attackType = wp.attackType;
            projectile = wp.projectile;
        }
        else if(weaponID == 1 || weaponID == 3 || weaponID == 4 || weaponID == 5 || weaponID == 6)        //근거리 무기들
        {
            attackType = wp.attackType;
            totalAttackSpeed = wp.attackSpeed + attackSpeed;
            totalDamage = damage + wp.damage;
        }
        


        if (isLeft)
        {
            hand.transform.position = new Vector2(transform.position.x - 0.4f, transform.position.y - 0.6f);
        }
        else
        {
            hand.transform.position = new Vector2(transform.position.x + 0.4f, transform.position.y - 0.6f);
        }

        if (!isChanged)
            weapon = weapon_1;
        else
            weapon = weapon_2;

        //무기 변경
        if (change && !isChangeCooldown)
        {
            isChangeCooldown = true;
            Destroy(equipWeapon);
            if (isChanged)
            {
                isChanged = false;
                weapon = weapon_1;
            }
            else
            {
                isChanged = true;
                weapon = weapon_2;
            }
            ui.WeaponChange();
            if(weapon != null)
                equipWeapon = Instantiate(weapon, transform.position, Quaternion.identity);
            wp = equipWeapon.GetComponent<Weapon>();
            PlaySound("Click");
            
        }

        if (isChangeCooldown)
        {
            changeTime += Time.deltaTime;
            if (changeTime >= 1.0f)
            {
                isChangeCooldown = false;
                changeTime = 0;
            }
        }

        //}
        //공격(
        if (Time.time - lastAttackTime > maxComboDelay) {	//Combo timer
			noOfClicks = 0;
		}
	
		if (!isAttack && attackType == 0 && !isDashing) {	//attackType 이 0인 공격
            target = new Vector3(joyStick.inputVector.x, joyStick.inputVector.y, 0);
            if (Mathf.Abs(joyStick.inputVector.x) >= 0.01f || Mathf.Abs(joyStick.inputVector.y) >= 0.01f)
            {
                isAttack = true;
                if (!isCharged)
                {
                    if (noOfClicks == 3)    //3단 콤보까지만 실행 제한
                        noOfClicks = 0;
                    noOfClicks++;
                    if (target.x < 0)
                    {
                        sr.flipX = true;
                        isLeft = true;
                        basicAttackDummy[noOfClicks - 1].transform.position = new Vector2(transform.position.x - 1.4f, transform.position.y + 0.2f);
                        basicAttackDummy[noOfClicks - 1].SetActive(true);
                    }
                    else if (target.x >= 0)
                    {
                        sr.flipX = false;
                        isLeft = false;
                        basicAttackDummy[noOfClicks - 1].transform.position = new Vector2(transform.position.x + 1.4f, transform.position.y + 0.2f);
                        basicAttackDummy[noOfClicks - 1].SetActive(true);
                    }
                    PlaySound("HeavySlash");
                    wp.WeaponAttack();
                    basicAttackDummy[noOfClicks - 1].GetComponent<Attack>().StartCoroutine(basicAttackDummy[noOfClicks - 1].GetComponent<Attack>().DesTimer()); //Destroy dummy

                }

                isCharged = false;
                chargeTime = 0;
                lastAttackTime = Time.time;
                StartCoroutine(AttackDelay());
            }

            
		}

		if(!isAttack_Range && attackType == 1){		//attackType이 1인 공격
            if (Mathf.Abs(joyStick.inputVector.x) >= 0.01f || Mathf.Abs(joyStick.inputVector.y) >= 0.01f)
            {
                target = transform.position + new Vector3(joyStick.inputVector.x, joyStick.inputVector.y, 0);
                isAttack_Range = true;
                GameObject bolt = Instantiate(projectile, transform.position, Quaternion.identity);
                bolt.GetComponent<Projectile>().targetPos = target;
                StartCoroutine(RangeAttackDelay());
            }
		}

        
        if(attackType == 2)     //attackType이 2인 공격
        {
            target = new Vector3(joyStick.inputVector.x, joyStick.inputVector.y , 0);
            if (Mathf.Abs(joyStick.inputVector.x) >= 0.01f || Mathf.Abs(joyStick.inputVector.y) >= 0.01f)
            {
                equipWeapon.transform.rotation = Quaternion.Euler(0, 0, Mathf.Atan2(joyStick.inputVector.y, joyStick.inputVector.x) * Mathf.Rad2Deg + 270.0f);
                if (!isAttack)
                {
                    isAttack = true;
                    target = joyStick.inputVector;
                    if (joyStick.inputVector != Vector3.zero)
                    {
                        spearAttackDummy.transform.position = hand.transform.position + (joyStick.GetComponent<JoyStick>().inputVector * 5);
                        spearAttackDummy.SetActive(true);
                        if(weaponID == 5)
                        {
                            GameObject fireAttack = Instantiate(fire, spearAttackDummy.transform.position, Quaternion.identity);
                            fireAttack.GetComponent<Attack>().StartCoroutine(fireAttack.GetComponent<Attack>().FireOn());
                        }
                    }

                    PlaySound("Slash");
                    spearAttackDummy.transform.rotation = Quaternion.Euler(0, 0, Mathf.Atan2(joyStick.inputVector.y, joyStick.inputVector.x) * Mathf.Rad2Deg);
                    spearAttackDummy.GetComponent<Attack>().StartCoroutine(spearAttackDummy.GetComponent<Attack>().DesTimer()); //Destroy dummy

                    StartCoroutine(AttackDelay());
                }
            }
            else
            {
                equipWeapon.transform.rotation = Quaternion.Euler(0, 0, 0);
            }
            

            
        }


		
		//)


            if (rid.velocity.y < 0)
                foot.layer = 17;
	}




	void PlaySound(string sn){		//Hierarcky에 있는 사운드 오브젝트를 불러와 재생
		GameObject.Find (sn).GetComponent<AudioSource> ().Play ();	
	}


    public void PickWeapon(int id, GameObject pickWeapon)   //슬롯에 아이템 유무에 따라 아이템 장착
    {

        if (!isChanged)
        {
            weapon = weapon_1;
            if(weapon_1 != null)
            {
                if (weapon_2 == null)
                {
                    weaponID_2 = id;
                    weapon_2 = pickWeapon;
                    isEquip = false;
                }
                else
                {
                    Instantiate(weaponItems[weaponID], transform.position, Quaternion.identity);
                    Destroy(equipWeapon);
                    weaponID_1 = id;
                    weapon_1 = pickWeapon;
                    isEquip = true;
                }
            }
            else
            {
                Destroy(equipWeapon);
                weaponID_1 = id;
                weapon_1 = pickWeapon;
                isEquip = true;
            }
        }
        else
        {
            weapon = weapon_2;
            
            if (weapon_2 != null)
            {
                if (weapon_1 == null)
                {
                    weaponID_1 = id;
                    weapon_1 = pickWeapon;
                    isEquip = false;
                }
                else
                {
                    Instantiate(weaponItems[weaponID], transform.position, Quaternion.identity);
                    Destroy(equipWeapon);
                    weaponID_2 = id;
                    weapon_2 = pickWeapon;
                    isEquip = true;
                }
            }
            else
            {
                Destroy(equipWeapon);
                weaponID_2 = id;
                weapon_2 = pickWeapon;
                isEquip = true;
            }
        }

        if (isEquip)
        {
            equipWeapon = Instantiate(pickWeapon, transform.position, Quaternion.identity);
            wp = equipWeapon.GetComponent<Weapon>();
            wp.Reset();
        }

        
    }
    
    public void PickItem(int id, GameObject pickItem)
    {
        switch (id)
        {
            case 1:
                moveSpeed += 3;
                break;
            case 2:
                maxHp += 5;
                hp += 5;
                break;
            case 3:
                damage += 2;
                maxHp -= 5;
                break;
            case 4:
                moveSpeed += 1;
                damage += 1;
                maxHp += 2;
                break;
            case 5:
                damage += 1;
                break;
            case 6:
                DataManager.Instance.MoneyValueUp(5);
                break;
            case 7:
                dashLength += 0.1f;
                break;
        }
        pickedItems[items] = id;
        if(items != pickedItems.Length - 1)
            items++;
        Destroy(pickItem);
    }

    //몬스터 피격(
    public void Attacked(float damage){
		if (!isDashing && !isInv) {
			isInv = true;
			StartCoroutine (InvincibleTime ());
			hp -= damage;
		}
	}

		
	IEnumerator InvincibleTime(){	//무저적시간
		sr.color = new Color32 (255, 255, 255, 180);
		yield return new WaitForSeconds (1.0f);
		sr.color = new Color32 (255, 255, 255, 255);
		isInv = false;
	}
	//)

	IEnumerator AttackDelay(){	//공격 간 딜레이
		yield return new WaitForSeconds (totalAttackSpeed);
		isAttack = false;
			
	}

	IEnumerator RangeAttackDelay(){	//원거리 공격 간 딜레이
		yield return new WaitForSeconds (totalAttackSpeed_Range);
		isAttack_Range = false;
	}

	IEnumerator DashTimer(){	//대쉬 딜레이
		yield return new WaitForSeconds (0.6f);
		dashCooldown = false;

	}
		
	void OnTriggerEnter2D(Collider2D other){
		if (other.CompareTag ("EnemyAttack")) {
			Attacked(other.gameObject.GetComponent<EnemyAttack>().damage);
		}
	}

    void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.CompareTag("Trigger"))
        {
            ui.StartCoroutine(ui.Dialog("주인공", "필기구는 챙겨야겠지?", true));
        }

        

    }

    void OnCollisionStay2D(Collision2D other)
    {
        if (other.gameObject.CompareTag("ground"))
        {
            isJumping = false;
            anim.SetBool("isJump", false);
        }
    }

	void OnTriggerStay2D(Collider2D other){
		if(other.CompareTag("ground")){
			isJumping = false;
            anim.SetBool("isJump", false);
        }
	}

	void OnTriggerExit2D(Collider2D other){
		if (other.CompareTag("ground")){
			isJumping = true;
		}
	}

    public void Load()
    {
        moveSpeed = DataManager.Instance.moveSpeed;
        dashLength = DataManager.Instance.dashLength;
        hp = DataManager.Instance.hp;
        maxHp = DataManager.Instance.maxHp;
        damage = DataManager.Instance.damage;

        weaponID_1 = DataManager.Instance.weaponID_1;
        weaponID_2 = DataManager.Instance.weaponID_2;


        items = DataManager.Instance.items;

        if (weaponID_1 != 0)
            PickWeapon(DataManager.Instance.weaponID_1, DataManager.Instance.weapon_1);
        if (weaponID_2 != 0)
            PickWeapon(DataManager.Instance.weaponID_2, DataManager.Instance.weapon_2);

        for (int i = 0; i < DataManager.Instance.items; i++)
        {
            DataManager.Instance.pickedItems[i] = pickedItems[i];
        }

        load = false;
    }
}
