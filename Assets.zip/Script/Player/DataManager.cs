﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DataManager : MonoBehaviour {

    private static DataManager _instance = null;

    private int moneyValue = 0;
    public int money = 0;
    public float moveSpeed = 0;
    public float dashSpeed = 0;
    public float hp = 0;
    public float maxHp = 0;
    public float damage = 0;

    public int weaponID = 0;
    public int weaponID_1 = 0;
    public int weaponID_2 = 0;

    public int[] pickedItems = new int[10];
    public int items = 0;
    public float dashLength;

    public GameObject weapon;
    public GameObject weapon_1;
    public GameObject weapon_2;

    public GameObject player;

    void Awake()
    {
        DontDestroyOnLoad(gameObject);
    }

    public static DataManager Instance
    {
        get
        {
            if(_instance == null)
            {
                _instance = FindObjectOfType(typeof(DataManager)) as DataManager;
                if(_instance == null)
                {
                    Debug.Log("No DataManager");
                }
            }

            return _instance;
        }
    }

    public void MoneyValueUp(int val)
    {
        moneyValue += val;
    }

    public void MoneyUp(int val)
    {
        money += val + moneyValue;
    }

    void OnApplicationQuit()
    {
        _instance = null;
        //게임종료시 삭제. 
    }

}
