﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HPbars : MonoBehaviour {

	public GameObject monster;
	EnemyBase monsterState;
	public Image bar;
	void Start () {
		monsterState = monster.GetComponent<EnemyBase> ();
	}
	
	// Update is called once per frame
	void Update () {
		bar.fillAmount = monsterState.hp / monsterState.startHp;
	}
}
