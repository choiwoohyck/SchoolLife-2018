﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Item : MonoBehaviour {

    public Canvas canvas;
    PlayerController pCon;

    public int itemID;      //아이템 id값

    void Start () {
        pCon = GameObject.Find("Player").GetComponent<PlayerController>();
	}

	void Update () {
		
	}

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            canvas.gameObject.SetActive(true);
        }
    }

    void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            canvas.gameObject.SetActive(false);
        }
    }

    public void ItemPick()
    {
        pCon.PickItem(itemID, gameObject);
    }
}
