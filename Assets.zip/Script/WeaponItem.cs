﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class WeaponItem : MonoBehaviour {

    public Canvas canvas;
    public int weaponID;
    public GameObject weapon;

    GameObject player;
    PlayerController pCon;


	void Start () {
        player = GameObject.Find("Player");
        pCon = player.GetComponent<PlayerController>();
	}

	void Update () {
		
	}

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            canvas.gameObject.SetActive(true);
        }
    }

    void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            canvas.gameObject.SetActive(false);
        }
    }

    public void ChangeWeapon()
    {
        
        pCon.PickWeapon(weaponID, weapon);
        Destroy(gameObject);
    }
}
