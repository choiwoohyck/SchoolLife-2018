﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class UIController : MonoBehaviour {

	public GameObject player;
	PlayerController pCon;
    public GameObject gm;
    GameManager gMan;

	public Image bar;
    public Image bossFull;
    public Image bossEmpty;

    public Sprite[] weaponSprite = new Sprite[10];    //ID에 따른 무기 이미지들
	public Image select1_item;      //1번슬롯 무기 이미지
	public Image select2_item;      //2번슬롯 무기 이미지
	public Image select1;           //1번슬롯 이미지
	public Image select2;           //2번슬롯 이미지

    public Image dialogImage;
    public Image dialog;

    public Image yougup;

    public int select1_weaponID = 0;    //1번슬롯 무기ID
    public int select2_weaponID = 0;    //2번슬롯 무기ID

    public Text money;

	public Vector2 sel1Pos;
	public Vector2 sel2Pos;

	bool isChanging = false;
	public bool isChanged = false;

    public bool isDialogStart = false;


    //페이드 인 아웃
    public Image panel;
    

    void Start () {
		pCon = player.GetComponent<PlayerController> ();
		sel1Pos = select1.rectTransform.position;
        sel2Pos = select2.rectTransform.position;
	}
	
	// Update is called once per frame
	void Update () {

        select1_item.sprite = weaponSprite[select1_weaponID];
        select2_item.sprite = weaponSprite[select2_weaponID];
        select1_weaponID = pCon.weaponID_1;
        select2_weaponID = pCon.weaponID_2;

        if (!isChanged)
        {
            pCon.weaponID = select1_weaponID;
        }
        else
        {
            pCon.weaponID = select2_weaponID;
        }

        if (select1_weaponID == 0)
            select1_item.color = new Color32(255, 255, 255, 0);
        else
            select1_item.color = new Color32(255, 255, 255, 255);
        if (select2_weaponID == 0)
            select2_item.color = new Color32(255, 255, 255, 0);
        else
            select2_item.color = new Color32(255, 255, 255, 255);

        bar.fillAmount = pCon.hp / pCon.maxHp;

		if (isChanging) {
			if (isChanged) {
				select1.transform.position = Vector2.Lerp (select1.transform.position, sel2Pos, 10.0f * Time.deltaTime);	
				select2.transform.position = Vector2.Lerp (select2.transform.position, sel1Pos, 10.0f * Time.deltaTime);	
			} else {
				select2.transform.position = Vector2.Lerp (select2.transform.position, sel2Pos, 10.0f * Time.deltaTime);	
				select1.transform.position = Vector2.Lerp (select1.transform.position, sel1Pos, 10.0f * Time.deltaTime);	
			}
		}

        money.text = DataManager.Instance.money + "원";

    }

	public void WeaponChange(){
		if (!isChanged) {
			isChanging = true;
			isChanged = true;
			StartCoroutine (Change ());

		} else {
			isChanging = true;
			isChanged = false;
			StartCoroutine (Change ());
		}
	}

	IEnumerator Change(){
		yield return new WaitForSeconds (0.1f);
		ColorChange ();
		yield return new WaitForSeconds (0.4f);
		isChanging = false;
	}
		
	void ColorChange(){
		if (isChanged) {
			select1.GetComponent<Image> ().color = new Color32 (95, 95, 95, 255);
			select2.GetComponent<Image> ().color = new Color32 (255, 255, 255, 255);
            if(select1_weaponID != 0)
			    select1_item.GetComponent<Image> ().color = new Color32 (95, 95, 95, 255);
            if(select2_weaponID != 0)
			    select2_item.GetComponent<Image> ().color = new Color32 (255, 255, 255, 255);
			select1.transform.SetSiblingIndex (select2.transform.GetSiblingIndex ());
		} else {
			select1.GetComponent<Image> ().color = new Color32 (255, 255, 255, 255);
			select2.GetComponent<Image> ().color = new Color32 (95, 95, 95, 255);
            if (select1_weaponID != 0)
                select1_item.GetComponent<Image> ().color = new Color32 (255, 255, 255, 255);
            if (select2_weaponID != 0)
                select2_item.GetComponent<Image> ().color = new Color32 (95, 95, 95, 255);
			select2.transform.SetSiblingIndex (select1.transform.GetSiblingIndex ());
		}
	}

    public void Fade()  //다른 스크립트에서 호출하는 용도
    {
        StartCoroutine(FadeInOut());
    }

    public void Dead()
    {
        StartCoroutine(FadeOut());
    }

    IEnumerator FadeInOut()
    {
        for(float f = 0.05f; f <= 1.05; f += 0.2f)
        {
            Color c = new Color(0, 0, 0, f);
            panel.color = c;
            yield return new WaitForSeconds(0.001f);
        }

        yield return new WaitForSeconds(0.4f);

        for (float f = 1.05f; f >= -0.05f; f -= 0.05f)
        {
            Color c = new Color(0, 0, 0, f);
            panel.color = c;
            yield return new WaitForSeconds(0.01f);
        }
    }

    IEnumerator FadeOut()
    {
        for (float f = 0.05f; f <= 1.05; f += 0.2f)
        {
            Color c = new Color(0, 0, 0, f);
            panel.color = c;
            yield return new WaitForSeconds(0.001f);
        }
        yield return new WaitForSeconds(2.0f);
        yougup.gameObject.SetActive(true);
        yield return new WaitForSeconds(2.0f);
        SceneManager.LoadScene(0);

    }

    public IEnumerator Dialog(string name, string text, bool isLast)
    {
        isDialogStart = true;
        string showText = "";
        dialog.gameObject.SetActive(true);
        dialogImage.gameObject.SetActive(true);
        dialog.GetComponent<Dialog>().name.text = name;
        for (int i = 0; i < text.Length; i++)
        {
            showText += text[i];
            dialog.GetComponent<Dialog>().contens.text = showText;
            yield return new WaitForSeconds(0.03f);
        }

        if (isLast)
        {
            yield return new WaitForSeconds(1.0f);
            dialog.gameObject.SetActive(false);
            dialogImage.gameObject.SetActive(false);
        }
        isDialogStart = false;
    }


}
