﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Store : MonoBehaviour {

    public GameObject[] itemPos = new GameObject[9];
    public GameObject[] items;
    public GameObject[] itemInstance;

    bool isIn = false;

	void Start () {
		for(int i = 0; i < items.Length; i++)
        {
            itemInstance[i] = Instantiate(items[i], itemPos[i].transform.position, Quaternion.identity);
        }
	}

    void Update()
    {

    }
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            Debug.Log("a");
            for (int i = 0; i < items.Length; i++)
                if (itemInstance[i] != null)
                    itemInstance[i].GetComponent<StoreItem>().canvas.gameObject.SetActive(true);
        }
    }
    void OnTriggerExit2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            Debug.Log("b");
            for (int i = 0; i < items.Length; i++)
                if(itemInstance[i] != null)
                    itemInstance[i].GetComponent<StoreItem>().canvas.gameObject.SetActive(false);
        }
    }
}
