﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AnimationEvent : MonoBehaviour {

	public void FootStep(){
		GameObject.Find ("Footstep").GetComponent<AudioSource> ().Play ();
	}
}
