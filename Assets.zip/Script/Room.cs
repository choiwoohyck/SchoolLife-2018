﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Room : MonoBehaviour {

    public bool doorLeft, doorRight, doorUp, doorBot;

    public GameObject leftDoor, rightDoor, upDoor, botDoor;
    public GameObject leftWall, rightWall, top, bot;
    public GameObject leftRoom, rightRoom, upRoom, botRoom;

    public GameObject stair;

    public GameObject[] enemys = new GameObject[5];
    public Transform[] enemySpawnPos = new Transform[5];
    GameObject[] spawnEnemys;

    public bool isCleared = false;
    public bool isSpawn = false;
    int enemyCnt;

    void Start()
    {
        spawnEnemys = new GameObject[enemys.Length];
        enemyCnt = enemys.Length;
    }

    void Update()
    {
        enemyCnt = GameObject.FindGameObjectsWithTag("Enemy").Length;
        if (enemyCnt <= 0 && isSpawn)
            isCleared = true;
        if(doorUp || doorBot)
        {
            stair.SetActive(true);
        }
    }

    public void CheckDoor()
    {
        if (doorLeft)
        {
            leftDoor.SetActive(true);
            leftDoor.GetComponent<Door>().doorType = 0;
        }
        if (doorRight)
        {
            rightDoor.SetActive(true);
            rightDoor.GetComponent<Door>().doorType = 1;
        }
        if (doorUp)
        {
            upDoor.SetActive(true);
            upDoor.GetComponent<Door>().doorType = 2;
        }
        if (doorBot)
        {
            botDoor.SetActive(true);
            botDoor.GetComponent<Door>().doorType = 3;
        }
    }

    public void SpawnEnemys()
    {
        for(int i = 0; i < enemys.Length; i++)
        {
            spawnEnemys[i] = Instantiate(enemys[i], enemySpawnPos[i].position, Quaternion.identity);
        }
    }


}
