﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Title : MonoBehaviour {

    public Image title;
    public Image start;
    public Image how;

    public Image[] images;
    public Image goLeft;
    public Image goRight;
    public Image back;

    int imageNumb = 0;
    bool isHow = false;

    void Awake()
    {
        
    }

    void Update()
    {
        if (imageNumb == 0)
            goLeft.color = new Color32(95, 95, 95, 255);
        else
            goLeft.color = new Color32(255, 255, 255, 255);
        if (imageNumb == images.Length - 1)
            goRight.color = new Color32(95, 95, 95, 255);
        else
            goRight.color = new Color32(255, 255, 255, 255);

        if ((Application.platform == RuntimePlatform.Android) && isHow)
        {
            if (Input.GetKey(KeyCode.Escape))
            {
                Back();
            }
        }
    }

	public void StartGame()
    {
        SceneManager.LoadScene(1);
    }

    public void HowToPlay()
    {
        isHow = true;
        title.gameObject.SetActive(false);
        start.gameObject.SetActive(false);
        how.gameObject.SetActive(false);

        back.gameObject.SetActive(true);
        goLeft.gameObject.SetActive(true);
        goRight.gameObject.SetActive(true);
        images[imageNumb].gameObject.SetActive(true);
    }

    public void GoLeft()
    {
        if(imageNumb != 0)
        {
            images[imageNumb].gameObject.SetActive(false);
            images[imageNumb - 1].gameObject.SetActive(true);
            imageNumb -= 1;
        }
    }

    public void GoRight()
    {
        if(imageNumb != images.Length - 1)
        {
            images[imageNumb].gameObject.SetActive(false);
            images[imageNumb + 1].gameObject.SetActive(true);
            imageNumb += 1;
        }
    }

    public void Back()
    {
        isHow = false;
        images[imageNumb].gameObject.SetActive(false);
        goLeft.gameObject.SetActive(false);
        goRight.gameObject.SetActive(false);
        back.gameObject.SetActive(false);
        imageNumb = 0;

        title.gameObject.SetActive(true);
        start.gameObject.SetActive(true);
        how.gameObject.SetActive(true);
    }
}
