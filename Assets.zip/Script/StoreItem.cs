﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class StoreItem : MonoBehaviour {

    public GameObject weapon;

    PlayerController pCon;
    public Canvas canvas;
    public int type = 0;  //0 = 소모성 (바로사용됨 포션 등), 1 = 패시브 아이템, 2 = 무기
    public int id;          //소모품, 아이템, 무기의 ID값

    public int price;

    public Text priceText;

	void Start () {
        pCon = GameObject.Find("Player").GetComponent<PlayerController>();
        priceText.text = price + "원";
    }

	void Update () {
		
	}

    public void ChooseItem()
    {
        if (price <= DataManager.Instance.money)
        {
            
            if (type == 0)
            {
                if (pCon.hp == pCon.maxHp)
                    return;
                switch (id)
                {
                    case 0:
                        pCon.hp += 5;
                        break;
                    case 1:
                        pCon.hp += 10;
                        break;
                }
                Destroy(gameObject);
            }
            if (type == 1)
            {
                pCon.PickItem(id, gameObject);
            }
            if (type == 2)
            {
                pCon.PickWeapon(id, weapon);
                Destroy(gameObject);
            }
            DataManager.Instance.money -= price;
        }
    }

}
