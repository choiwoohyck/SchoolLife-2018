﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawner : MonoBehaviour {

    PlayerController pCon;
    MapGenerator mg;
    Room room;


	// Use this for initialization
	void Start () {
        pCon = GameObject.Find("Player").GetComponent<PlayerController>();
        mg = GameObject.Find("MapGenerator").GetComponent<MapGenerator>();
    }
	
	// Update is called once per frame
	public void Spawn() {
        room = mg.roomObject[pCon.mapPosY, pCon.mapPosX].GetComponent<Room>();
        if (!room.isCleared)
        {
            room.SpawnEnemys();
            room.isSpawn = true;
        }
	}
}
