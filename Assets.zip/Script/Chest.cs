﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Chest : MonoBehaviour {

    public Canvas canvas;
    public Sprite openChest;
    SpriteRenderer sr;
    PlayerController pCon;

    bool isOpen = false;
    bool isFull = false;

    int cnt = 0;

    public GameObject[] weapons = new GameObject[2];
    public GameObject[] items = new GameObject[6];

	void Start () {
        pCon = GameObject.Find("Player").GetComponent<PlayerController>();
        sr = GetComponent<SpriteRenderer>();
	}
	
	void Update () {
	}

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player") && !isOpen)
        {
            canvas.gameObject.SetActive(true);
        }
    }
    void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
            canvas.gameObject.SetActive(false);
    }

    public void OpenChest()     //상자 여는 버튼에 들어갈 함수
    {
        isOpen = true;
        canvas.gameObject.SetActive(false);
        sr.sprite = openChest;
        int weaponOrItem = Random.Range(0, 4);
        if(weaponOrItem == 0)
        {
            GameObject weapon = Instantiate(weapons[Random.Range(0, weapons.Length)], transform.position, Quaternion.identity);
            weapon.GetComponent<Rigidbody2D>().AddForce(new Vector2(Random.Range(-0.4f, 0.4f), 1) * 500.0f);
        }
        else
        {
            
            int itemID = Random.Range(0, items.Length);
            cnt = 0;
            while (CheckItem(itemID))
            {
                itemID = Random.Range(0, items.Length);
            }
            Debug.Log(items.Length + " " + cnt);
            if (!isFull)
            {
                GameObject item = Instantiate(items[itemID], transform.position, Quaternion.identity);
                item.GetComponent<Rigidbody2D>().AddForce(new Vector2(Random.Range(-0.4f, 0.4f), 1) * 300.0f);
            }
        }
        
        StartCoroutine(DestroyChest());
    }

    bool CheckItem(int id)
    {
        if (cnt == items.Length)
        {
            isFull = true;
            return false;
        }
        for (int i = 0; i <= pCon.items; i++)
        {
            if(items[id].GetComponent<Item>().itemID == pCon.pickedItems[i])
            {
                cnt++;
                return true;
            }
        }
        
        return false;
    }

    IEnumerator DestroyChest()
    {
        sr.color = new Color32(180, 180, 180, 90);
        yield return new WaitForSeconds(0.5f);
        sr.color = new Color32(180, 180, 180, 255);
        yield return new WaitForSeconds(0.5f);
        sr.color = new Color32(180, 180, 180, 90);
        yield return new WaitForSeconds(0.5f);
        sr.color = new Color32(180, 180, 180, 255);
        yield return new WaitForSeconds(0.5f);
        Destroy(gameObject);
    }
}
