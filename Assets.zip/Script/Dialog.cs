﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Dialog : MonoBehaviour {

    public Text name;
    public Text contens;
	
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
