﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EndingPlayer : MonoBehaviour {

    public bool graduation = false;
    public bool go = false;

    float walkTimer = 0.0f;

    public Sprite gradu;
    SpriteRenderer rend;
    // Use this for initialization
    void Start () {
        rend = GetComponent<SpriteRenderer>();
    }
	
	// Update is called once per frame
	void Update () {


        walkTimer += Time.deltaTime;


		if (go)
        {
         rend.sprite = gradu;

        }


    }
}
