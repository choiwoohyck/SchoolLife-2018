﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class EndingManager : MonoBehaviour
{

    EndingUI uCon;
    GameObject Player;
    public Sprite player_2;
    int cnt = 0;

    int dialog = 1;
    bool runOneTime = true;

    bool stop = true;
    bool eStop = true;
    bool isEnd = false;

    public bool isMonsterDead = false;

    bool start = false;

    bool fade;
    float skipTimer = 0;

    bool runFirst = true;

    // Use this for initialization
    void Start()
    {
        Player = GameObject.Find("Player");
        uCon = GameObject.Find("UIController").GetComponent<EndingUI>();
      //  uCon.HideCanvas();
        uCon.StartCoroutine(uCon.FadeIn());
    }

    void Update()
    {
        if (runFirst)
        {
            uCon.dialogImage.sprite = uCon.juingong;
            uCon.StartCoroutine(uCon.Dialog("주인공", "역시 수능... 조금 어려웠네", false));
            runFirst = false;
        }

        if (dialog == 1)
        {

            if (Input.GetMouseButtonDown(0) && !uCon.isDialogStart)
            {
                switch (cnt)
                {
                    case 0:
                        uCon.dialogImage.sprite = uCon.juingong;
                        uCon.StartCoroutine(uCon.Dialog("주인공", "하지만 지금까지 열심히 '공부'했기 때문에 이겨냈다", false));
                        break;
                    case 1:
                        uCon.dialogImage.sprite = uCon.juingong;
                        uCon.StartCoroutine(uCon.Dialog("주인공", "졸업식 까지는 휴식을 해야겠군.", false));
                        break;
                    case 2:
                        dialog = 0;
                        break;
                }
                cnt++;

            }
        }

        if (dialog == 2)
        {

            if (Input.GetMouseButtonDown(0) && !uCon.isDialogStart)
            {
                switch (cnt)
                {
                    case 0:
                        uCon.dialogImage.sprite = uCon.juingong;
                        uCon.StartCoroutine(uCon.Dialog("주인공", "벌써 졸업이라니 즐거웠다.", false));
                        break;
                    case 1:
                        uCon.dialogImage.sprite = uCon.juingong;
                        uCon.StartCoroutine(uCon.Dialog("주인공", "아쉽지만 어쩔수 없지 대학에 가서 더 '공부'하는걸로 만족해야겠어", false));
                        break;
     
                }
                cnt++;

            }
        }

        if (cnt == 3)
        {
            uCon.panel2.gameObject.SetActive(true);
            uCon.second.gameObject.SetActive(true);
            skipTimer += Time.deltaTime;
        }

        if (skipTimer >= 0.5f)
        {
            uCon.panel2.gameObject.SetActive(false);
            uCon.second.gameObject.SetActive(false);
            uCon.HideCanvas();
            Player.GetComponent<EndingPlayer>().go = true;

         }

        if (skipTimer >= 1.0f)
        {
            dialog = 2;
            cnt = 0;
            uCon.ShowCanvaa();
            skipTimer = 0;
        }

        if (dialog == 2 && cnt >= 3)
        {
            uCon.panel2.gameObject.SetActive(true);
            uCon.second.gameObject.SetActive(true);
            uCon.second.text = "지금까지 School Life를 플레이 해주셔서 감사합니다.";
            StartCoroutine(End());
        }
    }

    IEnumerator End()
    {
        uCon.dialog.gameObject.SetActive(false);
        uCon.dialogImage.gameObject.SetActive(false);
        yield return new WaitForSeconds(2.0f);
        SceneManager.LoadScene(0);
    }





}
