﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour {

	public Transform targetTrans;
	public Transform minXTrans;	//카메라의 최소 x좌표	(왼쪽 벽 )
	public Transform maxXTrans;	//카메라의 최대 x좌표	(오른쪽 벽)
    public Transform minYTrans; //카메라의 최소 y좌표
    public Transform maxYTrans; //카메라의 최대 y좌표   (천장)

    public GameObject map;
    MapGenerator mapGenerator;
    public GameObject player;
    PlayerController pCon;

	float minX;
	float maxX;
    float minY;
    float maxY;

	float camPosX;
    float camPosY;

    void Start()
    {

        mapGenerator = map.GetComponent<MapGenerator>();
        pCon = player.GetComponent<PlayerController>();

        minXTrans = mapGenerator.roomObject[pCon.mapPosY, pCon.mapPosX].GetComponent<Room>().leftWall.transform;
        maxXTrans = mapGenerator.roomObject[pCon.mapPosY, pCon.mapPosX].GetComponent<Room>().rightWall.transform;
        minYTrans = mapGenerator.roomObject[pCon.mapPosY, pCon.mapPosX].GetComponent<Room>().bot.transform;
        maxYTrans = mapGenerator.roomObject[pCon.mapPosY, pCon.mapPosX].GetComponent<Room>().top.transform;
        minX = minXTrans.position.x + 11.1f;
        maxX = maxXTrans.position.x - 11.1f;
        minY = minYTrans.position.y + 6.2f;
        maxY = maxYTrans.position.y - 6.2f;
        camPosX = targetTrans.position.x;
        camPosY = targetTrans.position.y;
    }
        
	void FixedUpdate () {

        camPosX = targetTrans.position.x;
        camPosY = targetTrans.position.y;
        camPosX = Mathf.Clamp(camPosX, minX, maxX);
        camPosY = Mathf.Clamp(camPosY, minY, maxY);
        Vector3 targetPos = new Vector3 (camPosX, camPosY, -10);
		transform.position = Vector3.Lerp (transform.position, targetPos, Time.deltaTime * 10.0f);
	}

    public void Reset()
    {
        minXTrans = mapGenerator.roomObject[pCon.mapPosY, pCon.mapPosX].GetComponent<Room>().leftWall.transform;
        maxXTrans = mapGenerator.roomObject[pCon.mapPosY, pCon.mapPosX].GetComponent<Room>().rightWall.transform;
        minYTrans = mapGenerator.roomObject[pCon.mapPosY, pCon.mapPosX].GetComponent<Room>().bot.transform;
        maxYTrans = mapGenerator.roomObject[pCon.mapPosY, pCon.mapPosX].GetComponent<Room>().top.transform;
        minX = minXTrans.position.x + 11.1f;
        maxX = maxXTrans.position.x - 11.1f;
        minY = minYTrans.position.y + 6.2f;
        maxY = maxYTrans.position.y - 6.2f;
        camPosX = targetTrans.position.x;
        camPosY = targetTrans.position.y;
    }
}
