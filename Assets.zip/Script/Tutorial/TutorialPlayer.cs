﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TutorialPlayer : MonoBehaviour
{


    public float moveSpeed = 5.0f;		//이동속도
    public float dashSpeed = 3.0f;  //구르기 속도
    public float hp = 10.0f;            //체력
    public float maxHp = 10.0f;
    private float jumpSize = 680.0f;    //점프 크기
    public float attackSpeed = 0.8f;    //공격속도

    public bool moveLeft = false;
    public bool moveRight = false;
    public bool jump = false;           //버튼 관련
    public bool dash = false;
    public bool change = false;


    public bool isLeft = false;
    bool isMove = false;
    public bool isDashing = false;
    bool dashCooldown = false;
    bool isJumping = false;
    public bool isInv = false; //피격시 무적(Invincibility)


    public int mapPosX = 0; //맵 상에서의 플레이어의 위치
    public int mapPosY = 0;

    //공격 관련
    bool isAttack = false;          //근거리 공격중
    public int attackType = 9;      //공격의 종류 (0 = 검, 1 = 투사체 .... 9 = 무기없음)
    int noOfClicks = 0;
    float lastAttackTime = 0;
    float maxComboDelay = 0.8f; //콤보 간 최대 간격

    //무기 관련
    public int weaponID = 0;   //현재 장착중인 무기의 ID값   (0 = empty, 1 = pencil, 2 = eraser...
    public float damage;


    private float dashTime = 0.0f;
    public float dashLength = 0.1f;

    SpriteRenderer sr;
    Rigidbody2D rid;
    Animator anim;
    TutorialUI ui;
    Weapon_Tutorial wp;

    public GameObject pencil;

    public GameObject uiObj;

    public GameObject[] basicAttackDummy = new GameObject[3];
    public GameObject weapon;     //현재 장착중인 무기
    GameObject equipWeapon;       //장착중인 무기
    public GameObject hand;
    public GameObject fire;

    public GameObject afterImage_left;
    public GameObject afterImage_right;

    JoyStick joyStick;
    Vector3 target; //조이스틱 방향


    void Start()
    {
        maxHp = hp;
        ui = uiObj.GetComponent<TutorialUI>();
        sr = GetComponent<SpriteRenderer>();
        rid = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();

        

        afterImage_left.GetComponent<ParticleSystem>().Stop();
        afterImage_right.GetComponent<ParticleSystem>().Stop();
    }

    void FixedUpdate()
    {
        //캐릭터 이동(

        isMove = false;
        anim.SetBool("isRun", false);

        if (moveLeft && !isDashing)
        {
            transform.Translate(Vector3.left * moveSpeed * Time.deltaTime);
            isLeft = true;
            isMove = true;
            sr.flipX = true;
            anim.SetBool("isRun", true);
        }
        if (moveRight && !isDashing)
        {
            transform.Translate(Vector3.right * moveSpeed * Time.deltaTime);
            isLeft = false;
            isMove = true;
            sr.flipX = false;
            anim.SetBool("isRun", true);
        }

        //점프(
        if (jump && !isJumping)
        {
            gameObject.layer = 15;
            rid.AddForce(Vector2.up * jumpSize);
            isJumping = true;
            anim.SetBool("isJump", true);
        }
        //)

        //대쉬(
        if (dash && !isDashing && isMove)
        {
            if (!dashCooldown)
                isDashing = true;
        }
        if (isDashing && !dashCooldown)
        {
            if (dashTime <= dashLength)//대쉬 시간
            {
                dashTime += Time.deltaTime;
                if (isLeft)
                {
                    transform.Translate(Vector3.left * dashSpeed * Time.deltaTime);
                    afterImage_left.GetComponent<ParticleSystem>().Play();
                }
                else if (!isLeft)
                {
                    transform.Translate(Vector3.right * dashSpeed * Time.deltaTime);
                    afterImage_right.GetComponent<ParticleSystem>().Play();
                }
            }
            else
            {
                dashCooldown = true;
                dashTime = 0;
                isDashing = false;
                afterImage_left.GetComponent<ParticleSystem>().Stop();
                afterImage_right.GetComponent<ParticleSystem>().Stop();
                StartCoroutine(DashTimer());
            }
        }
        //)


        //Attack Setting(
        basicAttackDummy[0].GetComponent<Attack_Tutorial>().ccType = 0;
        basicAttackDummy[1].GetComponent<Attack_Tutorial>().ccType = 0;      //Set CC Type
        basicAttackDummy[2].GetComponent<Attack_Tutorial>().ccType = 0;

        basicAttackDummy[0].GetComponent<Attack_Tutorial>().power = 1;
        basicAttackDummy[1].GetComponent<Attack_Tutorial>().power = 1;               //Set CC Power
        basicAttackDummy[2].GetComponent<Attack_Tutorial>().power = 2;
        //)
    }

    void Update()
    {
        hp = Mathf.Clamp(hp, 0, maxHp);
        if (hp <= 0)
            gameObject.SetActive(false);


        //무기{
        if (weaponID == 0)      //무기없음
        {
            damage = 0;
            attackType = 9;
        }

        else if (weaponID == 1)        //근거리 무기들
        {
            damage = wp.damage;
            attackType = wp.attackType;
            attackSpeed = wp.attackSpeed;
        }


        if (isLeft)
        {
            hand.transform.position = new Vector2(transform.position.x - 0.4f, transform.position.y - 0.6f);
        }
        else
        {
            hand.transform.position = new Vector2(transform.position.x + 0.4f, transform.position.y - 0.6f);
        }


        //}
        //공격(
        if (Time.time - lastAttackTime > maxComboDelay)
        {   //Combo timer
            noOfClicks = 0;
        }

        if (!isAttack && attackType == 0 && !isDashing)
        {	//attackType 이 0인 공격
            target = new Vector3(joyStick.inputVector.x, joyStick.inputVector.y, 0);
            if (Mathf.Abs(joyStick.inputVector.x) >= 0.01f || Mathf.Abs(joyStick.inputVector.y) >= 0.01f)
            {
                isAttack = true;

                if (noOfClicks == 3)    //3단 콤보까지만 실행 제한
                    noOfClicks = 0;
                noOfClicks++;
                if (target.x < 0)
                {
                    sr.flipX = true;
                    isLeft = true;
                    basicAttackDummy[noOfClicks - 1].transform.position = new Vector2(transform.position.x - 1.4f, transform.position.y + 0.2f);
                    basicAttackDummy[noOfClicks - 1].SetActive(true);
                }
                else if (target.x >= 0)
                {
                    sr.flipX = false;
                    isLeft = false;
                    basicAttackDummy[noOfClicks - 1].transform.position = new Vector2(transform.position.x + 1.4f, transform.position.y + 0.2f);
                    basicAttackDummy[noOfClicks - 1].SetActive(true);
                }
                PlaySound("HeavySlash");
                wp.WeaponAttack();
                basicAttackDummy[noOfClicks - 1].GetComponent<Attack_Tutorial>().StartCoroutine(basicAttackDummy[noOfClicks - 1].GetComponent<Attack_Tutorial>().DesTimer()); //Destroy dummy


                lastAttackTime = Time.time;
                StartCoroutine(AttackDelay());
            }


        }

        if (isJumping)
        {   //플레이어가 떨어지는 중이면 레이어 변경
            if (rid.velocity.y < 0)
                gameObject.layer = 9;
        }
    }


    void PlaySound(string sn)
    {       //Hierarcky에 있는 사운드 오브젝트를 불러와 재생
        GameObject.Find(sn).GetComponent<AudioSource>().Play();
    }


    //몬스터 피격(
    public void Attacked(float damage)
    {
        if (!isDashing && !isInv)
        {
            isInv = true;
            StartCoroutine(InvincibleTime());
            hp -= damage;
        }
    }

    public void Equip()
    {
        GameObject equipWeapon = Instantiate(pencil, transform.position, Quaternion.identity);
        weapon = equipWeapon;
        wp = weapon.GetComponent<Weapon_Tutorial>();
        weaponID = 1;
        joyStick = GameObject.Find("BackGroundImage").GetComponent<JoyStick>();
    }


    IEnumerator InvincibleTime()
    {   //무저적시간
        sr.color = new Color32(255, 255, 255, 180);
        yield return new WaitForSeconds(1.0f);
        sr.color = new Color32(255, 255, 255, 255);
        isInv = false;
    }
    //)

    IEnumerator AttackDelay()
    {   //공격 간 딜레이
        yield return new WaitForSeconds(attackSpeed);
        isAttack = false;

    }

    IEnumerator DashTimer()
    {   //대쉬 딜레이
        yield return new WaitForSeconds(0.6f);
        dashCooldown = false;

    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("EnemyAttack"))
        {
            Attacked(other.gameObject.GetComponent<EnemyAttack>().damage);
        }
    }

    void OnTriggerStay2D(Collider2D other)
    {
        if (other.CompareTag("ground"))
        {
            isJumping = false;
            anim.SetBool("isJump", false);
        }
    }

    void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("ground"))
        {
            isJumping = true;
        }
    }
}
