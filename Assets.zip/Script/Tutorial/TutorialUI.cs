﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TutorialUI : MonoBehaviour
{

    public GameObject player;
    TutorialPlayer pCon;
    public Image bar;
    public Image bossFull;
    public Image bossEmpty;

    public Image dialogImage;
    public Image dialog;

    public Canvas canvas;
    public Canvas joyStickCanvas;
    
    public bool isDialogStart = false;

    public Sprite juingong;
    public Sprite elite;


    //페이드 인 아웃
    public Text first;
    public Image panel;

    public bool gameStart = false;


    void Start()
    {
        pCon = player.GetComponent<TutorialPlayer>();
    }

    // Update is called once per frame
    void Update()
    {
        bar.fillAmount = pCon.hp / pCon.maxHp;
    }

    public void Fade()  //다른 스크립트에서 호출하는 용도
    {
        StartCoroutine(FadeInOut());
    }

    IEnumerator FadeInOut()
    {
        
        for (float f = 0.05f; f <= 1.05; f += 0.2f)
        {
            Color c = new Color(0, 0, 0, f);
            panel.color = c;
            yield return new WaitForSeconds(0.001f);
        }

        yield return new WaitForSeconds(0.4f);

        for (float f = 1.05f; f >= -0.05f; f -= 0.05f)
        {
            Color c = new Color(0, 0, 0, f);
            panel.color = c;
            yield return new WaitForSeconds(0.01f);
        }
    }

    public IEnumerator FadeIn()
    {
        Debug.Log("a");
        yield return new WaitForSeconds(3.0f);
        for (float f = 1.05f; f >= -0.05f; f -= 0.05f)
        {
            Color c = new Color(0, 0, 0, f);
            panel.color = c;
            first.color = c;
            yield return new WaitForSeconds(0.01f);
        }
        gameStart = true;
    }

    public IEnumerator Dialog(string name, string text, bool isLast)
    {
        isDialogStart = true;
        string showText = "";
        dialog.gameObject.SetActive(true);
        dialogImage.gameObject.SetActive(true);
        dialog.GetComponent<Dialog>().name.text = name;
        for (int i = 0; i < text.Length; i++)
        {
            showText += text[i];
            dialog.GetComponent<Dialog>().contens.text = showText;
            yield return new WaitForSeconds(0.01f);
        }

        if (isLast)
        {
            yield return new WaitForSeconds(1.5f);
            dialog.gameObject.SetActive(false);
            dialogImage.gameObject.SetActive(false);
        }
        isDialogStart = false;
    }

    public void HideCanvas()
    {
        canvas.gameObject.SetActive(false);
        joyStickCanvas.gameObject.SetActive(false);
    }

    public void ShowCanvaa()
    {
        canvas.gameObject.SetActive(true);
        joyStickCanvas.gameObject.SetActive(true);
        pCon.Equip();
    }


}
