﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Attack_Tutorial : MonoBehaviour
{

    TutorialPlayer pCon;

    public float damage = 1.0f;
    public bool isLeft = false;
    public int ccType = 0;
    public float power = 0;
    public int spriteType = 0;

    float time = 1;

    void Awake()
    {
        pCon = GameObject.Find("Player").GetComponent<TutorialPlayer>();
    }

    void Start()
    {
        damage += pCon.damage;
    }

    void Update()
    {

        switch (spriteType)
        {
            case 0:
                if (isLeft)
                {
                    GetComponent<SpriteRenderer>().flipX = false;
                }
                else
                    GetComponent<SpriteRenderer>().flipX = true;
                break;
            case 1:
                if (isLeft)
                {
                    GetComponent<SpriteRenderer>().flipX = true;
                }
                else
                    GetComponent<SpriteRenderer>().flipX = false;
                break;
        }
        if (isLeft)
        {
            transform.Translate(Vector3.left * 0.01f);
        }
        else
        {
            transform.Translate(Vector3.right * 0.01f);
        }

    }
    public IEnumerator DesTimer()
    {
        GetComponent<SpriteRenderer>().enabled = true;
        isLeft = pCon.isLeft;
        yield return new WaitForSeconds(0.15f);
        GetComponent<SpriteRenderer>().enabled = false;
        gameObject.SetActive(false);
    }


}
