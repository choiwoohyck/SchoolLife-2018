﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Elite_Tutorial : MonoBehaviour
{       //플레이어와의 충돌을 감지하기 위한 스크립트

    EnemyBase eb;
    Attack_Tutorial at;
    Projectile pj;
    TutorialUI uCon;

    void Start()
    {
        uCon = GameObject.Find("UIController").GetComponent<TutorialUI>();
        eb = GetComponentInParent<EnemyBase>();
    }

    void Update()
    {
        uCon.bossFull.fillAmount = eb.hp / eb.startHp;
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("PlayerAttack"))
        {
            at = other.GetComponent<Attack_Tutorial>();
            eb.isDamaged = true;
            eb.hp -= at.damage - eb.DEF;
            eb.StartCoroutine(eb.Damaged(at.isLeft, at.ccType, at.power));
        }

    }
}
