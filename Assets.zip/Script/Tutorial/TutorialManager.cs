﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class TutorialManager : MonoBehaviour
{

    TutorialUI uCon;
    int cnt = 0;

    int dialog = 0;
    bool runOneTime = true;

    bool stop = true;
    bool eStop = true;
    bool isEnd = false;

    public bool isMonsterDead = false;

    bool start = false;

    public GameObject player;
    public GameObject elite;
    public GameObject elite_monster;

    // Use this for initialization
    void Start()
    {
        uCon = GameObject.Find("UIController").GetComponent<TutorialUI>();
        uCon.HideCanvas();
        uCon.StartCoroutine(uCon.FadeIn());
        

    }

    void Update()
    {
        if (uCon.gameStart)
        {
            uCon.gameStart = false;
            StartCoroutine(GameStory_1());
        }
        if (isEnd)
        {
            if (!uCon.isDialogStart){
                isEnd = false;
                StartCoroutine(GameStory_2());
            }
        }

        if (dialog == 1)
        {
            if (runOneTime)
            {
                runOneTime = false;
                uCon.dialogImage.sprite = uCon.elite;
                uCon.StartCoroutine(uCon.Dialog("???", "너가 오늘 전학온 주인공이라는 녀석이냐?", false));

            }
            if (Input.GetMouseButtonDown(0) && !uCon.isDialogStart)
            {
                switch (cnt)
                {
                    case 0:
                        uCon.dialogImage.sprite = uCon.juingong;
                        uCon.StartCoroutine(uCon.Dialog("주인공", "뭐야 지금 시비거는거야? 그래 내가 주인공이다 그러는 너는 누구야?", false));
                        break;
                    case 1:
                        uCon.dialogImage.sprite = uCon.elite;
                        uCon.StartCoroutine(uCon.Dialog("엘리트", "나는 이 학교 전교 1등인 엘리트다 전 학교에서 공부로 꽤나 이름날린 녀석이라길래 궁김해서 찾아와본거야", false));
                        break;
                    case 2:
                        uCon.dialogImage.sprite = uCon.juingong;
                        uCon.StartCoroutine(uCon.Dialog("주인공", "그래 니가아는 그사람이니까 이제 좀 비켜주지그래?", false));
                        break;
                    case 3:
                        uCon.dialogImage.sprite = uCon.elite;
                        uCon.StartCoroutine(uCon.Dialog("엘리트", "아니아니... 그렇게는 안되지 너가 얼마나 대단한지 궁금해졌어.. 나와 공부로 겨루자!", false));
                        break;
                    case 4:
                        uCon.dialogImage.sprite = uCon.juingong;
                        uCon.StartCoroutine(uCon.Dialog("주인공", "뭐?", true));
                        elite.SetActive(false);
                        elite_monster.SetActive(true);
                        dialog = 0;
                        uCon.ShowCanvaa();
                        runOneTime = true;
                        break;
                }
                cnt++;

            }
        }

        if(dialog == 2)
        {
            if (runOneTime)
            {
                runOneTime = false;
                uCon.HideCanvas();
                uCon.dialogImage.sprite = uCon.elite;
                uCon.StartCoroutine(uCon.Dialog("엘리트", "하하 제법 강하네 잘 봤어 다음번에는 안봐주니까 몸조심하고 있으라고?", false));
                cnt = 0;
            }
            if (Input.GetMouseButtonDown(0) && !uCon.isDialogStart)
            {
                switch (cnt)
                {
                    case 0:
                        uCon.dialogImage.sprite = uCon.juingong;
                        uCon.StartCoroutine(uCon.Dialog("주인공", "흥 좋을대로 해라", false));
                        break;
                    case 1:
                        uCon.dialogImage.sprite = uCon.elite;
                        uCon.StartCoroutine(uCon.Dialog("엘리트", "너가 생각하는것처럼 우리학교는 그렇게 호락호락하지 않아 그럼! 행운을 빌게", false));
                        break;
                    case 2:
                        uCon.dialogImage.sprite = uCon.juingong;
                        uCon.StartCoroutine(uCon.Dialog("주인공", "넌 진짜 이상한녀석이야", true));
                        StartCoroutine(ChangeMainScene());
                        break;
                }
                cnt++;

            }
        }

        if(isMonsterDead)
        {
            dialog = 2;
        }




        if (!stop)
        {
            player.transform.Translate(Vector2.right * 4 * Time.deltaTime);
            player.GetComponent<Animator>().SetBool("isRun", true);
        }
        else
        {
            player.GetComponent<Animator>().SetBool("isRun", false);
        }
        if (!eStop)
        {
            elite.GetComponent<Animator>().SetBool("isRun", true);
            elite.transform.Translate(Vector2.left * 4 * Time.deltaTime);
        }
        else
            elite.GetComponent<Animator>().SetBool("isRun", false);
    }

    IEnumerator GameStory_1()
    {
        stop = false;
        yield return new WaitForSeconds(1.5f);
        stop = true;
        yield return new WaitForSeconds(1.5f);
        uCon.dialogImage.sprite = uCon.juingong;
        uCon.StartCoroutine(uCon.Dialog("주인공", "여기가 오늘부터 다니게될 학교구나....", true));
        isEnd = true;
    }

    IEnumerator GameStory_2()
    {
        eStop = false;
        yield return new WaitForSeconds(1.5f);
        eStop = true;
        yield return new WaitForSeconds(1.5f);
        dialog = 1;
    }

    IEnumerator ChangeMainScene()
    {
        yield return new WaitForSeconds(1.0f);
        SceneManager.LoadScene(2);
    }



}
